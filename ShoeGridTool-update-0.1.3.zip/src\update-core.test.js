const test = require("node:test");
const assert = require("node:assert/strict");

const {
  compareVersions,
  isNewerVersion,
  parseJsonText,
  validateManifest,
  isSafeZipEntry,
} = require("./update-core");

test("compares semantic versions numerically", () => {
  assert.equal(compareVersions("0.1.10", "0.1.2"), 1);
  assert.equal(compareVersions("0.1.0", "0.1.0"), 0);
  assert.equal(compareVersions("0.1.0", "0.1.1"), -1);
  assert.equal(isNewerVersion("0.2.0", "0.1.9"), true);
  assert.equal(isNewerVersion("0.1.0", "0.1.0"), false);
});

test("validates GitHub update manifest", () => {
  const manifest = validateManifest({
    version: "0.1.1",
    notes: "Small UI update",
    packageUrl: "https://github.com/example/repo/releases/download/v0.1.1/ShoeGridTool-update-0.1.1.zip",
    sha256: "a".repeat(64),
  });

  assert.equal(manifest.version, "0.1.1");
  assert.equal(manifest.notes, "Small UI update");
});

test("parses JSON text that starts with a UTF-8 BOM", () => {
  const payload = parseJsonText("\uFEFF{\"version\":\"0.1.1\"}");
  assert.equal(payload.version, "0.1.1");
});

test("rejects unsafe manifests", () => {
  assert.throws(() => validateManifest({ version: "0.1.1" }), /packageUrl/);
  assert.throws(() => validateManifest({
    version: "0.1.1",
    packageUrl: "file:///C:/bad.zip",
    sha256: "a".repeat(64),
  }), /https/);
  assert.throws(() => validateManifest({
    version: "0.1.1",
    packageUrl: "https://github.com/example/repo/releases/download/v0.1.1/a.zip",
    sha256: "bad",
  }), /sha256/);
});

test("allows only safe update zip entries", () => {
  assert.equal(isSafeZipEntry("package.json"), true);
  assert.equal(isSafeZipEntry("src/main.js"), true);
  assert.equal(isSafeZipEntry("src/assets/app-logo.png"), true);
  assert.equal(isSafeZipEntry("../main.js"), false);
  assert.equal(isSafeZipEntry("C:/Windows/system32/calc.exe"), false);
  assert.equal(isSafeZipEntry("resources/app/src/main.js"), false);
});
