import argparse
import json
import os
import sys
import traceback
from pathlib import Path


RESULT_PREFIX = "__SAM3_RESULT__"
RESULT_SUFFIX = "__END__"


def emit_result(payload):
    sys.stdout.write(RESULT_PREFIX + json.dumps(payload, ensure_ascii=False) + RESULT_SUFFIX)
    sys.stdout.flush()


def load_job(path):
    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)


def choose_device(torch, requested):
    if requested == "cuda" and torch.cuda.is_available():
        return "cuda"
    if requested == "mps" and hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    if requested == "cpu":
        return "cpu"
    return "cuda" if torch.cuda.is_available() else "cpu"


def normalize_masks(masks, width, height):
    import numpy as np

    if masks is None:
        return np.zeros((0, height, width), dtype=bool)

    if hasattr(masks, "detach"):
        masks = masks.detach().cpu().numpy()

    array = np.asarray(masks)
    if array.size == 0:
        return np.zeros((0, height, width), dtype=bool)

    array = np.squeeze(array)
    if array.ndim == 2:
        array = array.reshape((1, array.shape[0], array.shape[1]))
    elif array.ndim == 3:
        array = array.reshape((-1, array.shape[-2], array.shape[-1]))
    else:
        array = array.reshape((-1, array.shape[-2], array.shape[-1]))

    return array > 0


def mask_bbox_ratio(mask):
    import numpy as np

    rows, cols = np.where(mask)
    if rows.size == 0 or cols.size == 0:
        return 0
    box_width = cols.max() - cols.min() + 1
    box_height = rows.max() - rows.min() + 1
    return max(box_width / mask.shape[1], box_height / mask.shape[0])


def filter_mask_candidates(masks, scores=None, min_area_ratio=0.001, max_area_ratio=0.42, max_box_ratio=0.9, max_candidates=6):
    import numpy as np

    normalized = normalize_masks(masks, 1, 1)
    if normalized.size == 0:
        return []

    score_values = []
    if scores is not None:
        if hasattr(scores, "detach"):
            scores = scores.detach().cpu().numpy()
        score_values = np.asarray(scores).reshape(-1).tolist()

    candidates = []
    for index, mask in enumerate(normalized):
        area_ratio = float(np.count_nonzero(mask)) / float(mask.shape[0] * mask.shape[1])
        if area_ratio < min_area_ratio or area_ratio > max_area_ratio:
            continue
        if mask_bbox_ratio(mask) > max_box_ratio:
            continue
        score = float(score_values[index]) if index < len(score_values) else 0.0
        candidates.append((score, area_ratio, mask))

    candidates.sort(key=lambda candidate: (candidate[0], -candidate[1]), reverse=True)
    return [candidate[2] for candidate in candidates[:max_candidates]]


def masks_to_array(masks, width, height, scores=None):
    import numpy as np
    from PIL import Image

    selected_masks = filter_mask_candidates(masks, scores=scores)
    if not selected_masks:
        return np.zeros((height, width), dtype=np.uint8)

    combined = np.logical_or.reduce(selected_masks)
    mask = (combined.astype(np.uint8) * 255)
    if mask.shape != (height, width):
        mask_image = Image.fromarray(mask, mode="L")
        mask_image = mask_image.resize((width, height), Image.Resampling.NEAREST)
        mask = np.asarray(mask_image, dtype=np.uint8)
    return mask


def build_processor(job):
    import torch

    plugin_path = Path(job["pluginPath"])
    model_path = Path(job["modelPath"])
    if not plugin_path.exists():
        raise FileNotFoundError(f"Easy-Sam3 plugin not found: {plugin_path}")
    if not model_path.exists():
        raise FileNotFoundError(f"SAM3 model not found: {model_path}")

    sys.path.insert(0, str(plugin_path))

    from sam3.model_builder import build_sam3_image_model
    from sam3.model.sam3_image_processor import Sam3Processor

    device = choose_device(torch, str(job.get("device", "auto")).lower())
    model = build_sam3_image_model(
        device=device,
        eval_mode=True,
        checkpoint_path=str(model_path),
        load_from_HF=False,
        enable_segmentation=True,
        enable_inst_interactivity=False,
        compile=False,
    )
    processor = Sam3Processor(
        model=model,
        resolution=int(job.get("resolution", 1008)),
        device=device,
        confidence_threshold=float(job.get("threshold", 0.4)),
    )
    return processor, device


def segment_items(job):
    import numpy as np
    import torch
    from PIL import Image

    processor, device = build_processor(job)
    prompt = str(job.get("prompt") or "").strip()
    if not prompt:
        raise ValueError("Prompt is empty")

    items = []
    for item in job.get("items", []):
        input_path = Path(item["inputPath"])
        mask_path = Path(item["maskPath"])
        mask_path.parent.mkdir(parents=True, exist_ok=True)

        image = Image.open(input_path).convert("RGB")
        width, height = image.size

        with torch.inference_mode():
            state = processor.set_image(image)
            state = processor.set_text_prompt(prompt, state)
            mask = masks_to_array(state.get("masks"), width, height, scores=state.get("scores"))

        Image.fromarray(mask, mode="L").save(mask_path)
        items.append({
            "index": item.get("index"),
            "row": item.get("row"),
            "col": item.get("col"),
            "inputPath": str(input_path),
            "maskPath": str(mask_path),
            "pixels": int(np.count_nonzero(mask)),
        })

    return {
        "ok": True,
        "device": device,
        "items": items,
    }


def main():
    parser = argparse.ArgumentParser(description="Run local SAM3 semantic masks for crop images.")
    parser.add_argument("job", nargs="?", help="Path to the JSON job file.")
    parser.add_argument("--self-test", action="store_true", help="Validate the runner can be loaded.")
    args = parser.parse_args()

    if args.self_test:
        emit_result({"ok": True, "selfTest": True})
        return 0

    if not args.job:
        emit_result({"ok": False, "reason": "Missing job file"})
        return 2

    try:
        job = load_job(args.job)
        emit_result(segment_items(job))
        return 0
    except Exception as error:
        traceback.print_exc(file=sys.stderr)
        emit_result({"ok": False, "reason": str(error)})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
