const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const srcDir = __dirname;

test("source panel has a return-to-upload button wired in renderer", () => {
  const html = fs.readFileSync(path.join(srcDir, "index.html"), "utf8");
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");

  assert.match(html, /id="returnUploadButton"/);
  assert.match(renderer, /function returnToSourceUpload\(/);
  assert.match(renderer, /returnUploadButton\.addEventListener\("click", returnToSourceUpload\)/);
});

test("uploaded final composite becomes the paste-back source", () => {
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const loadFinalImage = renderer.match(/function loadFinalImageFromFile\(file\) \{[\s\S]*?\n\}/)?.[0] || "";

  assert.match(loadFinalImage, /drawImageToCanvas\(els\.finalCanvas, img\)/);
  assert.match(loadFinalImage, /state\.editedImage\s*=\s*img/);
});

test("update panel status messages are readable Chinese", () => {
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const updateBlock = renderer.match(/async function loadUpdateStatus\(\)[\s\S]*?function setupCustomCursor\(\)/)?.[0] || "";

  assert.match(updateBlock, /版本读取失败/);
  assert.match(updateBlock, /正在检查 GitHub 新版本/);
  assert.match(updateBlock, /发现新版本/);
  assert.match(updateBlock, /当前已是最新版本/);
  assert.match(updateBlock, /正在下载/);
  assert.match(updateBlock, /更新完成/);
  assert.match(updateBlock, /升级失败/);
  assert.doesNotMatch(updateBlock, /[鐗璇诲彇澶辫触姝ｅ湪妫€鏌戠幇褰撳墠鏇存柊瀹屾垚]/);
});

test("paste back follows the current slice grid instead of requiring 2x2", () => {
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const pasteBack = renderer.match(/async function pasteBack\(\) \{[\s\S]*?\n\}/)?.[0] || "";

  assert.match(pasteBack, /state\.cols\s*\*\s*state\.rows/);
  assert.doesNotMatch(pasteBack, /EDITED_GRID_COLS\s*\*\s*EDITED_GRID_ROWS/);
  assert.match(pasteBack, /await\s+pasteEditedCellToCrop\(ctx,\s*slice,\s*index\)/);
});

test("semantic paste back masks the edited crop instead of pasting a full square", () => {
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const pasteHelper = renderer.match(/async function pasteEditedCellToCrop\(ctx,\s*slice,\s*index\) \{[\s\S]*?\n\}/)?.[0] || "";

  assert.match(pasteHelper, /getEditedGridCell\(index,\s*state\.editedImage,\s*state\.cols,\s*state\.rows\)/);
  assert.match(pasteHelper, /state\.semanticCropItems\.find/);
  assert.match(pasteHelper, /maskDataUrl/);
  assert.match(pasteHelper, /globalCompositeOperation\s*=\s*"destination-in"/);
  assert.match(pasteHelper, /drawImage\(mask/);
  assert.match(renderer, /async function exportFinalImage\(\)[\s\S]*const pasted = await pasteBack\(\)/);
  assert.match(renderer, /async function openImageViewer\(\)[\s\S]*const pasted = await pasteBack\(\)/);
});

test("shoe grid feature follows the same theme system as feature one", () => {
  const css = fs.readFileSync(path.join(srcDir, "styles.css"), "utf8");

  assert.doesNotMatch(css, /body\[data-feature-view="shoeGrid"\]\s*\{[\s\S]*?--text:/);
  assert.match(css, /body\[data-theme="dark"\]\s+\.shoeGridSlot/);
  assert.match(css, /body\[data-theme="dark"\]\s+\.shoeGridOutputPanel/);
  assert.match(css, /body\[data-theme="dark"\]\s+\.shoeGridPreviewStage/);
});

test("shoe grid upload slots use the same cloud upload icon as feature one", () => {
  const html = fs.readFileSync(path.join(srcDir, "index.html"), "utf8");
  const shoeGridSection = html.match(/<div class="shoeGridUploadGrid"[\s\S]*?<\/div>\s*<input id="shoeGridInput"/)?.[0] || "";
  const cloudIconCount = (shoeGridSection.match(/class="uploadGlyph"/g) || []).length;

  assert.equal(cloudIconCount, 4);
  assert.doesNotMatch(shoeGridSection, /<span class="plusPrompt small uploadPrompt">\+<\/span>/);
  assert.match(shoeGridSection, /<path d="M9 22\.5H7\.5A5\.5 5\.5 0 0 1 7 11\.53/);
});

test("shoe grid has a right-aligned direct size match action", () => {
  const html = fs.readFileSync(path.join(srcDir, "index.html"), "utf8");
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const css = fs.readFileSync(path.join(srcDir, "styles.css"), "utf8");
  const shoeGridBar = html.match(/<div class="cropBar shoeGridBar">[\s\S]*?<\/div>\s*<\/section>/)?.[0] || "";

  assert.match(shoeGridBar, /class="cropBarGroup shoeGridActions"[\s\S]*id="directShoeGridButton"[\s\S]*id="generateShoeGridButton"[\s\S]*id="clearShoeGridButton"/);
  assert.match(shoeGridBar, /class="button actionButton directAction"[^>]*id="directShoeGridButton"/);
  assert.match(renderer, /directShoeGridButton:\s*document\.getElementById\("directShoeGridButton"\)/);
  assert.match(renderer, /function getDirectShoeGridCellSize\(/);
  assert.match(renderer, /height:\s*Math\.round\(baseWidth\s*\*\s*\(sourceHeight\s*\/\s*sourceWidth\)\)/);
  assert.match(renderer, /function directMatchShoeGrid\(/);
  assert.match(renderer, /const\s+\{\s*width:\s*cellWidth,\s*height:\s*cellHeight\s*\}\s*=\s*getDirectShoeGridCellSize\(\)/);
  assert.match(renderer, /canvas\.width\s*=\s*cellWidth\s*\*\s*2/);
  assert.match(renderer, /canvas\.height\s*=\s*cellHeight\s*\*\s*2/);
  assert.match(renderer, /ctx\.drawImage\(item\.img,\s*x,\s*y,\s*cellWidth,\s*cellHeight\)/);
  assert.match(renderer, /els\.directShoeGridButton\.addEventListener\("click", directMatchShoeGrid\)/);
  assert.match(renderer, /els\.directShoeGridButton\.disabled\s*=\s*Boolean\(active\)/);
  assert.match(css, /\.shoeGridActions\s*\{[\s\S]*justify-content:\s*end/);
  assert.match(css, /\.directAction\s*\{[\s\S]*background:\s*linear-gradient\(180deg,\s*#28c987,\s*#16a36b\)/);
});

test("app opens at the approved wide default window size", () => {
  const main = fs.readFileSync(path.join(srcDir, "main.js"), "utf8");
  const windowOptions = main.match(/new BrowserWindow\(\{[\s\S]*?\n\s*\}\);/)?.[0] || "";

  assert.match(windowOptions, /width:\s*2048,/);
  assert.match(windowOptions, /height:\s*1152,/);
  assert.match(windowOptions, /minWidth:\s*1440,/);
  assert.match(windowOptions, /minHeight:\s*900,/);
});

test("semantic mask controls default to full opacity and include feather beside expand", () => {
  const html = fs.readFileSync(path.join(srcDir, "index.html"), "utf8");
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const css = fs.readFileSync(path.join(srcDir, "styles.css"), "utf8");
  const gridRemixSourceItemRule = css.match(/\.gridRemixSourceItem\s*\{[^}]*\}/)?.[0] || "";
  const controls = html.match(/<div class="semanticMaskControls">[\s\S]*?<\/div>\s*<div class="buttonRow">/)?.[0] || "";

  assert.match(controls, /id="semanticOpacityInput"[^>]*value="1"/);
  assert.match(controls, /id="semanticOpacityValue">100%<\/span>/);
  assert.match(controls, /class="maskControlRow"/);
  assert.match(controls, /id="semanticExpandInput"/);
  assert.match(controls, /id="semanticFeatherInput"/);
  assert.match(renderer, /semanticOpacity:\s*1,/);
  assert.match(renderer, /semanticFeather:\s*0,/);
  assert.match(renderer, /featherPixels:\s*state\.semanticFeather/);
  assert.match(css, /\.maskControl input\[type="range"\]::-webkit-slider-runnable-track/);
});

test("slice editor follows dark theme instead of showing pale cards", () => {
  const css = fs.readFileSync(path.join(srcDir, "styles.css"), "utf8");
  const darkSliceEditorRule = css.match(/body\[data-theme="dark"\]\s+\.sliceEditor\s*\{[^}]*\}/)?.[0] || "";

  assert.match(css, /body\[data-theme="dark"\]\s+\.sliceEditor\s*\{/);
  assert.match(css, /body\[data-theme="dark"\]\s+\.sliceEditorImage\s*\{/);
  assert.match(css, /body\[data-theme="dark"\]\s+\.sliceEditorGrid\s*\{/);
  assert.doesNotMatch(darkSliceEditorRule, /rgba\(255,\s*255,\s*255,\s*\.78\)/);
});

test("crop toolbar keeps editable slice counts and a compact semantic module", () => {
  const html = fs.readFileSync(path.join(srcDir, "index.html"), "utf8");
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const css = fs.readFileSync(path.join(srcDir, "styles.css"), "utf8");
  const cropBar = html.match(/<div class="cropBar">[\s\S]*?<\/div>\s*<\/section>/)?.[0] || "";

  assert.match(cropBar, /id="buyerGridPresetButton"[\s\S]*?data-cols="2"[\s\S]*?data-rows="2"/);
  assert.match(cropBar, /id="mainGridPresetButton"[\s\S]*?data-cols="1"[\s\S]*?data-rows="1"/);
  assert.match(cropBar, /id="colsInput"[^>]*type="number"[^>]*value="2"/);
  assert.match(cropBar, /id="rowsInput"[^>]*type="number"[^>]*value="2"/);
  assert.match(cropBar, /class="cropBarGroup directGroup"/);
  assert.match(cropBar, /class="cropBarGroup semanticGroup"[\s\S]*id="semanticPromptInput"[\s\S]*id="semanticColorInput"[\s\S]*id="confirmCropButton"/);
  assert.doesNotMatch(cropBar, /semanticControlGroup/);
  assert.doesNotMatch(cropBar, /semanticCropGroup/);
  assert.match(cropBar, /id="semanticPromptInput"[^>]*value="shoes"/);
  assert.match(renderer, /gridPresetButtons:\s*document\.querySelectorAll\("\[data-grid-preset\]"\)/);
  assert.match(renderer, /function applyGridPreset\(button\)/);
  assert.match(renderer, /els\.colsInput\.addEventListener\("input", updateGridPresetButtons\)/);
  assert.match(renderer, /els\.rowsInput\.addEventListener\("input", updateGridPresetButtons\)/);
  assert.match(css, /\.gridPresetButton/);
  assert.match(css, /\.gridNumberField/);
  assert.match(css, /\.cropBar \.semanticFieldInput\s*\{/);
  assert.doesNotMatch(css, /\.cropBar\s*\{[\s\S]*grid-template-columns:\s*minmax\(610px,\s*auto\)/);
  assert.match(css, /\.cropBar\s*\{[\s\S]*flex-wrap:\s*wrap/);
  assert.match(css, /\.gridGroup\s*\{[\s\S]*flex:\s*1\s+1\s+min\(100%,\s*520px\)/);
  assert.match(css, /\.semanticGroup\s*\{[\s\S]*flex:\s*1\s+1\s+min\(100%,\s*360px\)/);
  assert.match(css, /\.shoeGridBar\s*\{[\s\S]*display:\s*grid/);
});

test("crop output matches the visible square selection without hidden padding", () => {
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const initialSliceMask = renderer.match(/mask:\s*\{[\s\S]*?paddingRatio:\s*[^,\n]+[\s\S]*?\}/)?.[0] || "";
  const getCropFunction = renderer.match(/function getCrop\(slice\) \{[\s\S]*?\n\}/)?.[0] || "";

  assert.match(initialSliceMask, /paddingRatio:\s*0,/);
  assert.doesNotMatch(getCropFunction, /const\s+pad\s*=\s*Math\.min\(slice\.width,\s*slice\.height\)\s*\*\s*mask\.paddingRatio/);
});

test("shoe grid empty upload surfaces reuse the clean centered upload treatment", () => {
  const html = fs.readFileSync(path.join(srcDir, "index.html"), "utf8");
  const css = fs.readFileSync(path.join(srcDir, "styles.css"), "utf8");
  const shoeGridSection = html.match(/<div class="shoeGridUploadGrid"[\s\S]*?<\/div>\s*<input id="shoeGridInput"/)?.[0] || "";
  const shoeGridEmpty = html.match(/<div class="plusPrompt small uploadPrompt" id="shoeGridEmpty">[\s\S]*?<\/div>/)?.[0] || "";

  assert.equal((shoeGridSection.match(/class="shoeGridSlot cleanUploadSurface"/g) || []).length, 4);
  assert.equal((shoeGridSection.match(/class="plusPrompt small uploadPrompt"/g) || []).length, 4);
  assert.doesNotMatch(shoeGridSection, /<b>/);
  assert.doesNotMatch(shoeGridSection, /<small>/);
  assert.match(shoeGridEmpty, /class="plusPrompt small uploadPrompt"[\s\S]*id="shoeGridEmpty"/);
  assert.match(shoeGridEmpty, /<svg class="uploadGlyph"/);
  assert.doesNotMatch(shoeGridEmpty, /id="shoeGridEmpty">4<\/div>/);
  const lightCleanSurfaceRule = css.match(/\.cleanUploadSurface\s*\{[\s\S]*?\n\}/)?.[0] || "";
  assert.match(lightCleanSurfaceRule, /linear-gradient\(45deg/);
  assert.match(lightCleanSurfaceRule, /linear-gradient\(-45deg/);
  assert.match(lightCleanSurfaceRule, /var\(--canvas\)/);
  assert.doesNotMatch(lightCleanSurfaceRule, /linear-gradient\(135deg/);
  assert.match(css, /\.cleanUploadSurface::before\s*\{/);
  assert.match(css, /\.shoeGridSlot\s*\{[\s\S]*place-items:\s*center/);
  assert.match(css, /\.shoeGridPreviewStage\.cleanUploadSurface/);
});

test("grid remix feature can upload grids, split tiles, select four, and render output", () => {
  const html = fs.readFileSync(path.join(srcDir, "index.html"), "utf8");
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const css = fs.readFileSync(path.join(srcDir, "styles.css"), "utf8");
  const gridRemixSourceItemRule = css.match(/\.gridRemixSourceItem\s*\{[^}]*\}/)?.[0] || "";

  assert.match(html, /data-view="gridRemix"[\s\S]*<span class="navIcon">03<\/span>[\s\S]*四宫格拆分重组/);
  assert.match(html, /class="panel gridRemixPanel gridRemixFeature"/);
  assert.match(html, /id="gridRemixInput"[^>]*type="file"[^>]*multiple/);
  assert.match(html, /class="gridRemixTopGrid"[\s\S]*id="gridRemixUploadZone"[\s\S]*id="gridRemixSourceList"/);
  assert.match(html, /id="splitGridButton"/);
  assert.match(html, /id="gridRemixTileList"/);
  assert.match(html, /id="gridRemixSelectionCount"/);
  assert.match(html, /id="recomposeGridButton"/);
  assert.match(html, /class="panel gridRemixOutputPanel gridRemixFeature"/);
  assert.match(html, /id="gridRemixCanvas"/);
  assert.match(html, /id="gridRemixEmpty"/);
  assert.match(renderer, /gridRemixSources:\s*\[\]/);
  assert.match(renderer, /gridRemixTiles:\s*\[\]/);
  assert.match(renderer, /function splitGridRemixSources\(/);
  assert.match(renderer, /function toggleGridRemixTileSelection\(/);
  assert.match(renderer, /function recomposeGridRemixSelection\(/);
  assert.match(renderer, /featureName === "gridRemix"/);
  assert.doesNotMatch(renderer, /label\.textContent\s*=\s*`\$\{index \+ 1\}\. \$\{source\.fileName\}`/);
  assert.match(css, /\.gridRemixFeature/);
  assert.match(css, /\.gridRemixTopGrid\s*\{[\s\S]*grid-template-columns:\s*minmax\(300px,\s*\.4fr\)\s+minmax\(0,\s*1fr\)/);
  assert.match(css, /\.gridRemixSourcePanel\s*\{/);
  assert.match(css, /\.gridRemixBar\s*\{[\s\S]*width:\s*100%/);
  assert.match(css, /\.gridRemixBar\s*\{[\s\S]*justify-content:\s*flex-end/);
  assert.match(css, /\.gridRemixBar\s+\.cropBarGroup\s*\{[\s\S]*width:\s*max-content/);
  assert.doesNotMatch(css, /content:\s*"上传图像列表"/);
  assert.match(css, /\.gridRemixSourceList\s*\{[\s\S]*grid-auto-flow:\s*column/);
  assert.match(css, /\.gridRemixSourceList\s*\{[\s\S]*grid-auto-columns:\s*160px/);
  assert.match(css, /\.gridRemixSourceList\s*\{[\s\S]*overflow-x:\s*auto/);
  assert.doesNotMatch(gridRemixSourceItemRule, /aspect-ratio:\s*1/);
  assert.match(gridRemixSourceItemRule, /padding:\s*0/);
  assert.match(gridRemixSourceItemRule, /height:\s*100%/);
  assert.match(gridRemixSourceItemRule, /overflow:\s*hidden/);
  assert.match(css, /\.gridRemixSourceItem\s+canvas\s*\{[\s\S]*width:\s*100%/);
  assert.match(css, /\.gridRemixSourceItem\s+canvas\s*\{[\s\S]*object-fit:\s*cover/);
  assert.match(css, /\.gridRemixSourceItem\s+canvas\s*\{[\s\S]*border-radius:\s*inherit/);
  assert.match(css, /\.gridRemixTileList/);
  assert.match(css, /\.gridRemixTile\.selected/);
});

test("canvas expand feature uses a canvas resize frame like feature one", () => {
  const html = fs.readFileSync(path.join(srcDir, "index.html"), "utf8");
  const renderer = fs.readFileSync(path.join(srcDir, "renderer.js"), "utf8");
  const css = fs.readFileSync(path.join(srcDir, "styles.css"), "utf8");
  const canvasExpandRenderBlock = renderer.slice(
    renderer.indexOf("function renderCanvasExpand()"),
    renderer.indexOf("async function loadCanvasExpandFile(file)")
  );
  const canvasExpandLoadBlock = renderer.slice(
    renderer.indexOf("async function loadCanvasExpandFile(file)"),
    renderer.indexOf("function updateCanvasExpandEditorScale()")
  );

  assert.match(html, /data-view="canvasExpand"[\s\S]*<span class="navIcon">04<\/span>/);
  assert.match(html, /class="panel canvasExpandPanel canvasExpandFeature"/);
  assert.match(html, /id="canvasExpandInput"[^>]*type="file"[^>]*accept="image\/\*"/);
  assert.match(html, /class="canvasExpandEditor"/);
  assert.match(html, /id="canvasExpandFrame"/);
  assert.match(html, /id="canvasExpandFrameHandle"/);
  assert.match(html, /id="canvasExpandReturnButton"/);
  assert.doesNotMatch(html, /id="expandTopInput"/);
  assert.doesNotMatch(html, /id="expandRightInput"/);
  assert.doesNotMatch(html, /id="expandBottomInput"/);
  assert.doesNotMatch(html, /id="expandLeftInput"/);
  assert.match(html, /id="canvasExpandSourceSize"[^>]*class="[^"]*canvasExpandSizePill/);
  assert.match(html, /id="expandColorInput"[^>]*type="color"[^>]*value="#ff0000"/);
  assert.match(html, /id="canvasExpandRatioButton"/);
  assert.match(html, /class="canvasExpandRatioMenu"[\s\S]*data-expand-ratio="1:1"[\s\S]*data-expand-ratio="3:4"[\s\S]*data-expand-ratio="4:3"/);
  assert.match(html, /id="renderCanvasExpandButton"/);
  assert.match(html, /class="panel canvasExpandOutputPanel canvasExpandFeature"/);
  assert.match(html, /id="canvasExpandCanvas"/);
  assert.match(html, /id="canvasExpandResolution"/);
  assert.match(html, /id="exportCanvasExpandButton"/);
  assert.match(renderer, /canvasExpandImage:\s*null/);
  assert.match(renderer, /canvasExpandFrame:\s*\{/);
  assert.match(renderer, /canvasExpandViewScale:\s*1/);
  assert.match(renderer, /canvasExpandPreviewReady:\s*false/);
  assert.match(renderer, /function updateCanvasExpandEditorScale\(/);
  assert.match(renderer, /function updateCanvasExpandSizePill\(/);
  assert.match(renderer, /function updateCanvasExpandFrameElement\(/);
  assert.match(renderer, /function bindCanvasExpandFrame\(/);
  assert.match(renderer, /function getCanvasExpandPaddingFromFrame\(/);
  assert.match(renderer, /function applyCanvasExpandRatio\(/);
  assert.match(renderer, /const sourceAspect = sourceWidth \/ sourceHeight/);
  assert.match(renderer, /widthRatio = heightRatio \* targetRatio \/ sourceAspect/);
  assert.match(renderer, /heightRatio = widthRatio \* sourceAspect \/ targetRatio/);
  assert.match(renderer, /function setCanvasExpandPreviewVisible\(/);
  assert.match(renderer, /function renderCanvasExpand\(/);
  assert.match(renderer, /请先上传一张需要扩图的图片/);
  assert.match(renderer, /扩图完成：\$\{canvas\.width\} x \$\{canvas\.height\}，尺寸已补齐为 16 的倍数/);
  assert.match(renderer, /请选择一张需要扩图的图片/);
  assert.doesNotMatch(canvasExpandRenderBlock, /璇峰厛涓婁紶|鎵╁浘瀹屾垚/);
  assert.doesNotMatch(canvasExpandLoadBlock, /璇烽€夋嫨/);
  assert.match(renderer, /canvasExpandUploadZone\.addEventListener\("click"[\s\S]*if\s*\(state\.canvasExpandImage\)\s*return/);
  assert.match(renderer, /canvasExpandUploadZone\.addEventListener\("wheel"/);
  assert.match(renderer, /canvasExpandSourceCanvas\.addEventListener\("wheel",\s*scaleCanvasExpandFrameFromWheel/);
  assert.match(renderer, /canvasExpandFrame\.addEventListener\("wheel"/);
  assert.match(renderer, /createCanvasExpandPlan\(sourceWidth,\s*sourceHeight,\s*getCanvasExpandPaddingFromFrame\(\)\)[\s\S]*canvasExpandSourceSize\.textContent\s*=\s*`\$\{plan\.width\} x \$\{plan\.height\}`/);
  assert.match(renderer, /canvasExpandReturnButton\.addEventListener\("click",\s*clearCanvasExpand\)/);
  assert.doesNotMatch(renderer, /loadCanvasExpandFile[\s\S]*renderCanvasExpand\(\);[\s\S]*function clearCanvasExpand/);
  assert.match(renderer, /createCanvasExpandPlan\(/);
  assert.match(renderer, /featureName === "canvasExpand"/);
  assert.match(renderer, /downloadCanvas\(els\.canvasExpandCanvas,\s*"canvas-expand.jpg"\)/);
  assert.match(css, /\.canvasExpandFeature/);
  assert.match(css, /\.canvasExpandSizePill/);
  assert.match(css, /\.canvasExpandBody\s*\{[\s\S]*grid-template-rows:\s*minmax\(0,\s*1fr\)\s+auto/);
  assert.match(css, /\.canvasExpandBody\s*\{[\s\S]*gap:\s*12px/);
  assert.match(css, /\.canvasExpandBody\s*\{[\s\S]*padding:\s*13px/);
  assert.match(css, /\.canvasExpandUpload\s*\{[\s\S]*place-items:\s*center/);
  assert.match(css, /\.canvasExpandEditor\s*\{[\s\S]*width:\s*min\(86%,\s*980px\)/);
  assert.match(css, /\.canvasExpandEditor/);
  assert.match(css, /transform:\s*scale\(var\(--canvas-expand-view-scale,\s*1\)\)/);
  assert.match(css, /\.canvasExpandFrame\s*\{[\s\S]*border:\s*2px solid #ff3b30/);
  assert.match(css, /\.canvasExpandFrameHandle\s*\{[\s\S]*background:\s*#ff3b30/);
  assert.match(css, /\.canvasExpandFrameHandle/);
  assert.match(css, /\.canvasExpandFrame::before/);
  assert.match(css, /\.canvasExpandRatioMenu/);
  assert.match(css, /body\[data-theme="dark"\]\s+\.canvasExpandRatioMenu\s*\{/);
  assert.match(css, /body\[data-theme="dark"\]\s+\.canvasExpandRatioMenu button\s*\{[\s\S]*color:\s*#f4f7ff/);
  assert.match(css, /\.canvasExpandOutputPanel:not\(\.hasPreview\)\s+\.imageStage/);
  assert.match(css, /body\[data-feature-view="canvasExpand"\]\s+\.canvasExpandFeature/);
});

test("package version stays at the requested 0.1.3 release line", () => {
  const appPackage = JSON.parse(fs.readFileSync(path.join(srcDir, "..", "package.json"), "utf8"));

  assert.equal(appPackage.version, "0.1.3");
});
