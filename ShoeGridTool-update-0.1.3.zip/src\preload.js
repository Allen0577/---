const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("shoeTransfer", {
  savePng(payload) {
    return ipcRenderer.invoke("save-png", payload);
  },
  savePngList(payload) {
    return ipcRenderer.invoke("save-png-list", payload);
  },
  copyPng(dataUrl) {
    return ipcRenderer.invoke("copy-png", dataUrl);
  },
  segmentSemanticCrops(payload) {
    return ipcRenderer.invoke("segment-semantic-crops", payload);
  },
  openPath(target) {
    return ipcRenderer.invoke("open-path", target);
  },
  getSavePathLock() {
    return ipcRenderer.invoke("get-save-path-lock");
  },
  setSavePathLock(payload) {
    return ipcRenderer.invoke("set-save-path-lock", payload);
  },
  getUpdateStatus() {
    return ipcRenderer.invoke("update:get-status");
  },
  checkForUpdates() {
    return ipcRenderer.invoke("update:check");
  },
  downloadAndApplyUpdate(manifest) {
    return ipcRenderer.invoke("update:download-and-apply", manifest);
  },
});
