﻿const state = {
  sourceImage: null,
  sourceName: "",
  activeModule: "source",
  cols: 2,
  rows: 2,
  slices: [],
  editedImage: null,
  doodleTarget: null,
  doodling: false,
  doodleHistory: [],
  doodleHistoryIndex: -1,
  semanticPrompt: "shoes",
  semanticColor: "#39ff6a",
  semanticOpacity: 1,
  semanticExpand: 0,
  semanticFeather: 0,
  semanticCropActive: false,
  semanticCropItems: [],
  activeFeature: "shoeTransfer",
  shoeGridImages: Array(4).fill(null),
  shoeGridInputIndex: 0,
  shoeGridBusy: false,
  gridRemixSources: [],
  gridRemixTiles: [],
  gridRemixSelectedTileIds: [],
  canvasExpandImage: null,
  canvasExpandFrame: {
    xRatio: -0.08,
    yRatio: -0.08,
    widthRatio: 1.16,
    heightRatio: 1.16,
  },
  canvasExpandViewScale: 1,
  canvasExpandPreviewReady: false,
  latestUpdate: null,
};

const DOODLE_HISTORY_LIMIT = 40;
const MAX_SEMANTIC_MASK_RATIO = 0.45;
const SAVE_PATH_KEY = "shoe-transfer-save-path";
const SAVE_PATH_LOCK_KEY = "shoe-transfer-save-path-locked";
const SHOE_GRID_EXPORT_MIME = "image/jpeg";
const SHOE_GRID_EXPORT_QUALITY = 0.94;
const SHOE_GRID_EXPORT_NAME = "shoe-grid.jpg";

const els = {
  toast: document.getElementById("appToast"),
  app: document.querySelector(".app"),
  modulePanels: document.querySelectorAll("[data-module]"),
  themeOptions: document.querySelectorAll("[data-theme-option]"),
  sidebarToggle: document.getElementById("sidebarToggle"),
  sourceInput: document.getElementById("sourceInput"),
  finalInput: document.getElementById("finalInput"),
  sourceCanvas: document.getElementById("sourceCanvas"),
  sliceEditorGrid: document.getElementById("sliceEditorGrid"),
  returnUploadButton: document.getElementById("returnUploadButton"),
  cropGridCanvas: document.getElementById("cropGridCanvas"),
  cropEmpty: document.getElementById("cropEmpty"),
  semanticProgress: document.getElementById("semanticProgress"),
  finalCanvas: document.getElementById("finalCanvas"),
  finalDropZone: document.getElementById("finalDropZone"),
  finalEmpty: document.getElementById("finalEmpty"),
  emptyState: document.getElementById("emptyState"),
  dropZone: document.getElementById("dropZone"),
  colsInput: document.getElementById("colsInput"),
  rowsInput: document.getElementById("rowsInput"),
  gridPresetButtons: document.querySelectorAll("[data-grid-preset]"),
  cropSizeInput: document.getElementById("cropSizeInput"),
  semanticPromptInput: document.getElementById("semanticPromptInput"),
  semanticColorInput: document.getElementById("semanticColorInput"),
  semanticOpacityInput: document.getElementById("semanticOpacityInput"),
  semanticOpacityValue: document.getElementById("semanticOpacityValue"),
  semanticExpandInput: document.getElementById("semanticExpandInput"),
  semanticFeatherInput: document.getElementById("semanticFeatherInput"),
  sliceButton: document.getElementById("sliceButton"),
  directCropButton: document.getElementById("directCropButton"),
  confirmCropButton: document.getElementById("confirmCropButton"),
  detectButton: document.getElementById("detectButton"),
  exportCropButton: document.getElementById("exportCropButton"),
  pasteBackButton: document.getElementById("pasteBackButton"),
  viewFinalButton: document.getElementById("viewFinalButton"),
  downloadFinalButton: document.getElementById("downloadFinalButton"),
  openSaveFolderButton: document.getElementById("openSaveFolderButton"),
  savePathInput: document.getElementById("savePathInput"),
  savePathLockButton: document.getElementById("savePathLockButton"),
  copyCropButton: document.getElementById("copyCropButton"),
  openCropEditorButton: document.getElementById("openCropEditorButton"),
  cropResolution: document.getElementById("cropResolution"),
  imageViewerOverlay: document.getElementById("imageViewerOverlay"),
  viewerCanvas: document.getElementById("viewerCanvas"),
  closeImageViewerButton: document.getElementById("closeImageViewerButton"),
  featureButtons: document.querySelectorAll(".featureButton"),
  doodleOverlay: document.getElementById("doodleOverlay"),
  doodleCanvas: document.getElementById("doodleCanvas"),
  doodleCanvasShell: document.querySelector(".doodleCanvasShell"),
  brushSizeInput: document.getElementById("brushSizeInput"),
  brushSmoothInput: document.getElementById("brushSmoothInput"),
  brushOpacityInput: document.getElementById("brushOpacityInput"),
  brushColorInput: document.getElementById("brushColorInput"),
  undoDoodleButton: document.getElementById("undoDoodleButton"),
  redoDoodleButton: document.getElementById("redoDoodleButton"),
  cancelDoodleButton: document.getElementById("cancelDoodleButton"),
  saveDoodleButton: document.getElementById("saveDoodleButton"),
  maskPrompt: document.getElementById("maskPrompt"),
  sliceGrid: document.getElementById("sliceGrid"),
  shoeGridInput: document.getElementById("shoeGridInput"),
  shoeGridUploadGrid: document.getElementById("shoeGridUploadGrid"),
  shoeGridSlots: document.querySelectorAll("[data-shoe-slot]"),
  shoeGridSlotCanvases: document.querySelectorAll("[data-shoe-canvas]"),
  shoeGridCount: document.getElementById("shoeGridCount"),
  shoeGridPromptInput: document.getElementById("shoeGridPromptInput"),
  shoeGridCellSizeInput: document.getElementById("shoeGridCellSizeInput"),
  directShoeGridButton: document.getElementById("directShoeGridButton"),
  generateShoeGridButton: document.getElementById("generateShoeGridButton"),
  clearShoeGridButton: document.getElementById("clearShoeGridButton"),
  shoeGridCanvas: document.getElementById("shoeGridCanvas"),
  shoeGridEmpty: document.getElementById("shoeGridEmpty"),
  shoeGridProgress: document.getElementById("shoeGridProgress"),
  shoeGridResolution: document.getElementById("shoeGridResolution"),
  exportShoeGridButton: document.getElementById("exportShoeGridButton"),
  copyShoeGridButton: document.getElementById("copyShoeGridButton"),
  shoeGridSavePathInput: document.getElementById("shoeGridSavePathInput"),
  shoeGridSavePathLockButton: document.getElementById("shoeGridSavePathLockButton"),
  openShoeGridFolderButton: document.getElementById("openShoeGridFolderButton"),
  gridRemixInput: document.getElementById("gridRemixInput"),
  gridRemixUploadZone: document.getElementById("gridRemixUploadZone"),
  gridRemixSourceCount: document.getElementById("gridRemixSourceCount"),
  gridRemixSourceList: document.getElementById("gridRemixSourceList"),
  splitGridButton: document.getElementById("splitGridButton"),
  clearGridRemixButton: document.getElementById("clearGridRemixButton"),
  gridRemixTileList: document.getElementById("gridRemixTileList"),
  gridRemixSelectionCount: document.getElementById("gridRemixSelectionCount"),
  recomposeGridButton: document.getElementById("recomposeGridButton"),
  gridRemixCanvas: document.getElementById("gridRemixCanvas"),
  gridRemixEmpty: document.getElementById("gridRemixEmpty"),
  gridRemixResolution: document.getElementById("gridRemixResolution"),
  exportGridRemixButton: document.getElementById("exportGridRemixButton"),
  copyGridRemixButton: document.getElementById("copyGridRemixButton"),
  canvasExpandInput: document.getElementById("canvasExpandInput"),
  canvasExpandUploadZone: document.getElementById("canvasExpandUploadZone"),
  canvasExpandEditor: document.getElementById("canvasExpandEditor"),
  canvasExpandSourceCanvas: document.getElementById("canvasExpandSourceCanvas"),
  canvasExpandFrame: document.getElementById("canvasExpandFrame"),
  canvasExpandFrameHandle: document.getElementById("canvasExpandFrameHandle"),
  canvasExpandUploadPrompt: document.getElementById("canvasExpandUploadPrompt"),
  canvasExpandSourceSize: document.getElementById("canvasExpandSourceSize"),
  canvasExpandReturnButton: document.getElementById("canvasExpandReturnButton"),
  expandColorInput: document.getElementById("expandColorInput"),
  canvasExpandRatioButton: document.getElementById("canvasExpandRatioButton"),
  canvasExpandRatioMenu: document.getElementById("canvasExpandRatioMenu"),
  canvasExpandRatioButtons: document.querySelectorAll("[data-expand-ratio]"),
  renderCanvasExpandButton: document.getElementById("renderCanvasExpandButton"),
  clearCanvasExpandButton: document.getElementById("clearCanvasExpandButton"),
  canvasExpandCanvas: document.getElementById("canvasExpandCanvas"),
  canvasExpandEmpty: document.getElementById("canvasExpandEmpty"),
  canvasExpandResolution: document.getElementById("canvasExpandResolution"),
  exportCanvasExpandButton: document.getElementById("exportCanvasExpandButton"),
  copyCanvasExpandButton: document.getElementById("copyCanvasExpandButton"),
  currentVersionLabel: document.getElementById("currentVersionLabel"),
  updateStatusText: document.getElementById("updateStatusText"),
  updateNotesText: document.getElementById("updateNotesText"),
  checkUpdateButton: document.getElementById("checkUpdateButton"),
  applyUpdateButton: document.getElementById("applyUpdateButton"),
};

function setStatus(text) {
  console.debug("[shoe-transfer]", text);
}

function showToast(text) {
  if (!els.toast) return;
  window.clearTimeout(showToast.timer);
  els.toast.textContent = text;
  els.toast.hidden = false;
  showToast.timer = window.setTimeout(() => {
    els.toast.hidden = true;
  }, 3200);
}

function setUpdateBusy(isBusy) {
  if (els.checkUpdateButton) els.checkUpdateButton.disabled = isBusy;
  if (els.applyUpdateButton) els.applyUpdateButton.disabled = isBusy;
}

function setUpdateStatus(text) {
  if (els.updateStatusText) els.updateStatusText.textContent = text;
}

function setUpdateNotes(text) {
  if (!els.updateNotesText) return;
  els.updateNotesText.textContent = text || "";
  els.updateNotesText.hidden = !text;
}

async function loadUpdateStatus() {
  if (!window.shoeTransfer?.getUpdateStatus) return;
  try {
    const status = await window.shoeTransfer.getUpdateStatus();
    if (els.currentVersionLabel) {
      els.currentVersionLabel.textContent = status.currentVersion || "0.0.0";
    }
  } catch (error) {
    setUpdateStatus(`版本读取失败：${error.message}`);
  }
}

async function checkForUpdates() {
  if (!window.shoeTransfer?.checkForUpdates) return;
  setUpdateBusy(true);
  setUpdateNotes("");
  setUpdateStatus("正在检查 GitHub 新版本...");
  try {
    const manifest = await window.shoeTransfer.checkForUpdates();
    state.latestUpdate = manifest.hasUpdate ? manifest : null;
    if (manifest.hasUpdate) {
      setUpdateStatus(`发现新版本 ${manifest.version}`);
      setUpdateNotes(manifest.notes || "这个版本没有填写更新说明。");
      if (els.applyUpdateButton) els.applyUpdateButton.hidden = false;
    } else {
      setUpdateStatus(`当前已是最新版本 ${manifest.currentVersion}`);
      if (els.applyUpdateButton) els.applyUpdateButton.hidden = true;
    }
  } catch (error) {
    setUpdateStatus(`检查失败：${error.message}`);
    if (els.applyUpdateButton) els.applyUpdateButton.hidden = true;
  } finally {
    setUpdateBusy(false);
  }
}

async function applyAvailableUpdate() {
  if (!state.latestUpdate || !window.shoeTransfer?.downloadAndApplyUpdate) return;
  setUpdateBusy(true);
  setUpdateStatus(`正在下载 ${state.latestUpdate.version}，请不要关闭软件...`);
  try {
    await window.shoeTransfer.downloadAndApplyUpdate(state.latestUpdate);
    setUpdateStatus("更新完成，软件即将自动重启...");
    showToast("更新完成，正在重启");
  } catch (error) {
    setUpdateStatus(`升级失败：${error.message}`);
    setUpdateBusy(false);
  }
}

function setupCustomCursor() {
  const cursor = document.createElement("div");
  cursor.className = "customCursor";
  cursor.setAttribute("aria-hidden", "true");
  document.body.appendChild(cursor);

  let x = -100;
  let y = -100;
  let framePending = false;

  const render = () => {
    framePending = false;
    cursor.style.transform = `translate3d(${x - 3}px, ${y - 2}px, 0)`;
  };

  const queueRender = () => {
    if (framePending) return;
    framePending = true;
    window.requestAnimationFrame(render);
  };

  window.addEventListener("pointermove", (event) => {
    x = event.clientX;
    y = event.clientY;
    cursor.classList.add("visible");
    queueRender();
  }, { passive: true });

  window.addEventListener("pointerleave", () => cursor.classList.remove("visible"));
  window.addEventListener("blur", () => cursor.classList.remove("visible"));
}

function setSemanticProgress(active) {
  if (!els.semanticProgress) return;
  els.semanticProgress.hidden = !active;
  els.cropEmpty.style.display = active ? "none" : (els.cropGridCanvas.width > 1 && els.cropGridCanvas.height > 1 ? "none" : "grid");
}

function setCropResolution(width = 0, height = 0) {
  if (!els.cropResolution) return;
  els.cropResolution.textContent = width && height ? `${Math.round(width)} x ${Math.round(height)}` : "-- x --";
}

function setActiveModule(moduleName) {
  const nextModule = moduleName || "source";
  state.activeModule = nextModule;
  els.modulePanels.forEach((panel) => {
    const active = panel.dataset.module === nextModule;
    panel.classList.toggle("moduleActive", active);
    panel.classList.toggle("moduleLocked", !active);
    panel.setAttribute("aria-selected", String(active));
    panel.setAttribute("aria-disabled", String(!active));
  });
}

function setTheme(theme) {
  const nextTheme = theme === "dark" ? "dark" : "light";
  document.body.dataset.theme = nextTheme;
  els.themeOptions.forEach((button) => {
    const active = button.dataset.themeOption === nextTheme;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  localStorage.setItem("shoe-transfer-theme", nextTheme);
}

function setSavePathLocked(locked, options = {}) {
  const shouldLock = Boolean(locked);
  const savePath = els.savePathInput.value.trim();

  if (shouldLock && !savePath) {
    setStatus("请先填写保存路径再锁定");
    return;
  }

  els.savePathInput.readOnly = shouldLock;
  els.savePathLockButton.classList.toggle("locked", shouldLock);
  els.savePathLockButton.setAttribute("aria-pressed", String(shouldLock));
  els.savePathLockButton.textContent = shouldLock ? "已锁" : "锁";

  if (shouldLock) {
    localStorage.setItem(SAVE_PATH_KEY, savePath);
    localStorage.setItem(SAVE_PATH_LOCK_KEY, "1");
    window.shoeTransfer?.setSavePathLock?.({ savePath, locked: true })?.catch(() => {});
    if (!options.silent) setStatus("保存路径已锁定，下次打开会自动保留");
    return;
  }

  localStorage.removeItem(SAVE_PATH_LOCK_KEY);
  localStorage.removeItem(SAVE_PATH_KEY);
  window.shoeTransfer?.setSavePathLock?.({ savePath: "", locked: false })?.catch(() => {});
  if (!options.silent) setStatus("保存路径已解锁");
}

function persistSavePathIfLocked() {
  if (!els.savePathLockButton.classList.contains("locked")) return;
  const savePath = els.savePathInput.value.trim();
  if (savePath) {
    localStorage.setItem(SAVE_PATH_KEY, savePath);
    localStorage.setItem(SAVE_PATH_LOCK_KEY, "1");
    window.shoeTransfer?.setSavePathLock?.({ savePath, locked: true })?.catch(() => {});
  }
}

async function restoreSavePathLock() {
  let savedPath = localStorage.getItem(SAVE_PATH_KEY) || "";
  let locked = Boolean(savedPath && localStorage.getItem(SAVE_PATH_LOCK_KEY) === "1");

  try {
    const persisted = await window.shoeTransfer?.getSavePathLock?.();
    if (persisted?.savePath) {
      savedPath = persisted.savePath;
      locked = Boolean(persisted.locked);
    }
  } catch {
    // Keep localStorage fallback.
  }

  if (savedPath) {
    els.savePathInput.value = savedPath;
  }
  setSavePathLocked(Boolean(savedPath && locked), { silent: true });
}

function loadImageFromFile(file) {
  if (!file || !file.type.startsWith("image/")) {
    setStatus("璇烽€夋嫨鍥剧墖鏂囦欢");
    return;
  }

  const url = URL.createObjectURL(file);
  const img = new Image();
  img.onload = () => {
    URL.revokeObjectURL(url);
    state.sourceImage = img;
    state.sourceName = file.name || "clipboard-image";
    state.slices = [];
    state.editedImage = null;
    state.semanticCropActive = false;
    state.semanticCropItems = [];
    els.emptyState.style.display = "none";
    els.sourceCanvas.style.display = "block";
    els.sliceEditorGrid.style.display = "none";
    els.sliceEditorGrid.innerHTML = "";
    els.dropZone.classList.add("hasImage");
    els.dropZone.classList.remove("editing");
    drawSourcePreview();
    setStatus("鍘熷浘宸插鍏ワ紝鍙互璁剧疆鍒囩墖");
  };
  img.src = url;
}

function loadClipboardImageForActiveModule(file) {
  if (state.activeFeature === "gridRemix") {
    loadGridRemixFiles([file]);
    return;
  }

  if (state.activeFeature === "shoeGrid") {
    loadShoeGridFile(file, findFirstEmptyShoeGridSlot());
    return;
  }

  switch (state.activeModule) {
    case "final":
      loadFinalImageFromFile(file);
      break;
    case "source":
    default:
      loadImageFromFile(file);
      break;
  }
}

function loadFinalImageFromFile(file) {
  if (!file || !file.type.startsWith("image/")) {
    setStatus("请选择最终结果图片");
    return;
  }

  const url = URL.createObjectURL(file);
  const img = new Image();
  img.onload = () => {
    URL.revokeObjectURL(url);
    drawImageToCanvas(els.finalCanvas, img);
    state.editedImage = img;
    els.finalEmpty.style.display = "none";
    setStatus("最终图已导入，可以导出或继续贴图");
  };
  img.src = url;
}

function drawImageToCanvas(canvas, img) {
  canvas.width = img.naturalWidth || img.width;
  canvas.height = img.naturalHeight || img.height;
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  fitPreviewCanvas(canvas);
}

function clearCanvas(canvas) {
  canvas.width = 1;
  canvas.height = 1;
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, 1, 1);
  canvas.style.width = "";
  canvas.style.height = "";
}

function fitPreviewCanvas(canvas) {
  if (!canvas || !canvas.width || !canvas.height) return;

  const parent = canvas.parentElement;
  if (!parent) return;

  const applyFit = () => {
    const rect = parent.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const scale = Math.min(rect.width / canvas.width, rect.height / canvas.height);
    canvas.style.width = `${Math.max(1, Math.floor(canvas.width * scale))}px`;
    canvas.style.height = `${Math.max(1, Math.floor(canvas.height * scale))}px`;
  };

  applyFit();
  requestAnimationFrame(applyFit);
}

function copyCanvasToCanvas(sourceCanvas, targetCanvas) {
  targetCanvas.width = sourceCanvas.width;
  targetCanvas.height = sourceCanvas.height;
  const ctx = targetCanvas.getContext("2d");
  ctx.clearRect(0, 0, targetCanvas.width, targetCanvas.height);
  ctx.drawImage(sourceCanvas, 0, 0);
  fitPreviewCanvas(targetCanvas);
}

function fitAllPreviewCanvases() {
  [
    els.sourceCanvas,
    els.cropGridCanvas,
    els.finalCanvas,
    els.viewerCanvas,
    els.shoeGridCanvas,
    els.gridRemixCanvas,
    els.canvasExpandSourceCanvas,
    els.canvasExpandCanvas,
  ].forEach(fitPreviewCanvas);
}

function setEditedImageFromCanvas(canvas) {
  const img = new Image();
  img.onload = () => {
    state.editedImage = img;
    setCropResolution(img.naturalWidth || img.width, img.naturalHeight || img.height);
  };
  img.src = canvas.toDataURL("image/png");
}

function drawSourcePreview() {
  if (!state.sourceImage) return;
  drawImageToCanvas(els.sourceCanvas, state.sourceImage);
}

function returnToSourceUpload() {
  if (!state.sourceImage) {
    els.sourceInput.click();
    return;
  }

  state.slices = [];
  state.semanticCropActive = false;
  state.semanticCropItems = [];
  els.sliceEditorGrid.innerHTML = "";
  els.sliceEditorGrid.style.display = "none";
  els.sourceCanvas.style.display = "block";
  els.emptyState.style.display = "none";
  els.dropZone.classList.add("hasImage");
  els.dropZone.classList.remove("editing");
  clearCanvas(els.cropGridCanvas);
  els.cropEmpty.style.display = "grid";
  setCropResolution();
  drawSourcePreview();
  setActiveModule("source");
  setStatus("已返回原图上传页，可以重新切片");
}

function computeSlices(width, height, cols, rows) {
  const slices = [];
  const cellWidth = width / cols;
  const cellHeight = height / rows;

  for (let row = 0; row < rows; row += 1) {
    for (let col = 0; col < cols; col += 1) {
      const x = Math.round(col * cellWidth);
      const y = Math.round(row * cellHeight);
      const nextX = Math.round((col + 1) * cellWidth);
      const nextY = Math.round((row + 1) * cellHeight);
      slices.push({
        index: row * cols + col,
        col,
        row,
        x,
        y,
        width: nextX - x,
        height: nextY - y,
        mask: {
          xRatio: 0.28,
          yRatio: 0.58,
          sizeRatio: 0.32,
          paddingRatio: 0,
        },
      });
    }
  }

  return slices;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function roundUpToMultiple(value, multiple = 16) {
  return Math.ceil(Math.max(1, Math.round(Number(value) || 1)) / multiple) * multiple;
}

function createCanvasExpandPlan(sourceWidth, sourceHeight, padding = {}) {
  const top = Math.max(0, Math.round(Number(padding.top) || 0));
  const right = Math.max(0, Math.round(Number(padding.right) || 0));
  const bottom = Math.max(0, Math.round(Number(padding.bottom) || 0));
  const left = Math.max(0, Math.round(Number(padding.left) || 0));
  const contentWidth = sourceWidth + left + right;
  const contentHeight = sourceHeight + top + bottom;
  const width = roundUpToMultiple(contentWidth, 16);
  const height = roundUpToMultiple(contentHeight, 16);

  return {
    contentWidth,
    contentHeight,
    width,
    height,
    imageX: left,
    imageY: top,
    extraRight: width - contentWidth,
    extraBottom: height - contentHeight,
  };
}

function normalizeCanvasExpandFrame() {
  const frame = state.canvasExpandFrame;
  frame.widthRatio = clamp(Number(frame.widthRatio) || 1, 1, 4);
  frame.heightRatio = clamp(Number(frame.heightRatio) || 1, 1, 4);
  frame.xRatio = clamp(Number(frame.xRatio) || 0, 1 - frame.widthRatio, 0);
  frame.yRatio = clamp(Number(frame.yRatio) || 0, 1 - frame.heightRatio, 0);
}

function updateCanvasExpandEditorScale() {
  if (!els.canvasExpandEditor) return;
  const scale = clamp(Number(state.canvasExpandViewScale) || 1, 0.45, 2.8);
  state.canvasExpandViewScale = scale;
  els.canvasExpandEditor.style.setProperty("--canvas-expand-view-scale", String(scale));
}

function updateCanvasExpandSizePill() {
  if (!els.canvasExpandSourceSize) return;
  const item = state.canvasExpandImage;
  if (!item?.img) {
    els.canvasExpandSourceSize.textContent = "未上传";
    return;
  }
  const sourceWidth = item.img.naturalWidth || item.img.width;
  const sourceHeight = item.img.naturalHeight || item.img.height;
  const plan = createCanvasExpandPlan(sourceWidth, sourceHeight, getCanvasExpandPaddingFromFrame());
  els.canvasExpandSourceSize.textContent = `${plan.width} x ${plan.height}`;
}

function updateCanvasExpandFrameElement() {
  if (!els.canvasExpandFrame || !els.canvasExpandSourceCanvas) return;
  normalizeCanvasExpandFrame();
  const canvas = els.canvasExpandSourceCanvas;
  const frame = state.canvasExpandFrame;
  const left = canvas.offsetLeft + frame.xRatio * canvas.clientWidth;
  const top = canvas.offsetTop + frame.yRatio * canvas.clientHeight;
  els.canvasExpandFrame.style.left = `${left}px`;
  els.canvasExpandFrame.style.top = `${top}px`;
  els.canvasExpandFrame.style.width = `${frame.widthRatio * canvas.clientWidth}px`;
  els.canvasExpandFrame.style.height = `${frame.heightRatio * canvas.clientHeight}px`;
  updateCanvasExpandSizePill();
}

function getCanvasExpandPaddingFromFrame() {
  const item = state.canvasExpandImage;
  if (!item?.img) return { top: 0, right: 0, bottom: 0, left: 0 };
  normalizeCanvasExpandFrame();
  const sourceWidth = item.img.naturalWidth || item.img.width;
  const sourceHeight = item.img.naturalHeight || item.img.height;
  const frame = state.canvasExpandFrame;
  return {
    top: Math.round(Math.max(0, -frame.yRatio) * sourceHeight),
    right: Math.round(Math.max(0, frame.xRatio + frame.widthRatio - 1) * sourceWidth),
    bottom: Math.round(Math.max(0, frame.yRatio + frame.heightRatio - 1) * sourceHeight),
    left: Math.round(Math.max(0, -frame.xRatio) * sourceWidth),
  };
}

function scaleCanvasExpandFrameFromWheel(event) {
  if (!state.canvasExpandImage) return;
  event.preventDefault();
  event.stopPropagation();
  normalizeCanvasExpandFrame();
  const frame = state.canvasExpandFrame;
  const centerX = frame.xRatio + frame.widthRatio / 2;
  const centerY = frame.yRatio + frame.heightRatio / 2;
  const scale = event.deltaY < 0 ? 1.06 : 0.94;
  frame.widthRatio = clamp(frame.widthRatio * scale, 1, 4);
  frame.heightRatio = clamp(frame.heightRatio * scale, 1, 4);
  frame.xRatio = centerX - frame.widthRatio / 2;
  frame.yRatio = centerY - frame.heightRatio / 2;
  normalizeCanvasExpandFrame();
  updateCanvasExpandFrameElement();
  markCanvasExpandPreviewDirty();
}

function bindCanvasExpandFrame() {
  if (!els.canvasExpandFrame || !els.canvasExpandFrameHandle || !els.canvasExpandSourceCanvas || bindCanvasExpandFrame.bound) return;
  bindCanvasExpandFrame.bound = true;

  const startDrag = (event, mode) => {
    if (!state.canvasExpandImage) return;
    event.preventDefault();
    event.stopPropagation();
    const rect = els.canvasExpandSourceCanvas.getBoundingClientRect();
    const drag = {
      startX: event.clientX,
      startY: event.clientY,
      xRatio: state.canvasExpandFrame.xRatio,
      yRatio: state.canvasExpandFrame.yRatio,
      widthRatio: state.canvasExpandFrame.widthRatio,
      heightRatio: state.canvasExpandFrame.heightRatio,
      canvasWidth: Math.max(1, rect.width),
      canvasHeight: Math.max(1, rect.height),
    };

    const moveDrag = (moveEvent) => {
      const dx = (moveEvent.clientX - drag.startX) / drag.canvasWidth;
      const dy = (moveEvent.clientY - drag.startY) / drag.canvasHeight;
      if (mode === "move") {
        state.canvasExpandFrame.xRatio = clamp(drag.xRatio + dx, 1 - drag.widthRatio, 0);
        state.canvasExpandFrame.yRatio = clamp(drag.yRatio + dy, 1 - drag.heightRatio, 0);
      } else {
        state.canvasExpandFrame.widthRatio = clamp(drag.widthRatio + dx, 1 - drag.xRatio, 4);
        state.canvasExpandFrame.heightRatio = clamp(drag.heightRatio + dy, 1 - drag.yRatio, 4);
      }
      updateCanvasExpandFrameElement();
      markCanvasExpandPreviewDirty();
    };

    const stopDrag = () => {
      window.removeEventListener("mousemove", moveDrag);
      window.removeEventListener("mouseup", stopDrag);
    };

    window.addEventListener("mousemove", moveDrag);
    window.addEventListener("mouseup", stopDrag);
  };

  els.canvasExpandFrame.addEventListener("mousedown", (event) => startDrag(event, "move"));
  els.canvasExpandFrameHandle.addEventListener("mousedown", (event) => startDrag(event, "resize"));
  els.canvasExpandFrame.addEventListener("wheel", scaleCanvasExpandFrameFromWheel, { passive: false });
  els.canvasExpandSourceCanvas.addEventListener("wheel", scaleCanvasExpandFrameFromWheel, { passive: false });
}

function setCanvasExpandResolution(width = 0, height = 0) {
  if (!els.canvasExpandResolution) return;
  els.canvasExpandResolution.textContent = width && height ? `${Math.round(width)} x ${Math.round(height)}` : "-- x --";
}

function setCanvasExpandPreviewVisible(visible) {
  state.canvasExpandPreviewReady = Boolean(visible);
  const panel = els.canvasExpandCanvas?.closest(".canvasExpandOutputPanel");
  if (panel) panel.classList.toggle("hasPreview", state.canvasExpandPreviewReady);
  if (els.canvasExpandEmpty) els.canvasExpandEmpty.style.display = state.canvasExpandPreviewReady ? "none" : "grid";
}

function markCanvasExpandPreviewDirty() {
  if (els.canvasExpandCanvas) clearCanvas(els.canvasExpandCanvas);
  setCanvasExpandResolution();
  setCanvasExpandPreviewVisible(false);
}

function applyCanvasExpandRatio(ratioText) {
  const match = String(ratioText || "").match(/^(\d+(?:\.\d+)?):(\d+(?:\.\d+)?)$/);
  if (!match || !state.canvasExpandImage) return;
  const ratioWidth = Number.parseFloat(match[1]);
  const ratioHeight = Number.parseFloat(match[2]);
  if (!ratioWidth || !ratioHeight) return;

  normalizeCanvasExpandFrame();
  const frame = state.canvasExpandFrame;
  const centerX = frame.xRatio + frame.widthRatio / 2;
  const centerY = frame.yRatio + frame.heightRatio / 2;
  const targetRatio = ratioWidth / ratioHeight;
  const sourceWidth = state.canvasExpandImage.img.naturalWidth || state.canvasExpandImage.img.width;
  const sourceHeight = state.canvasExpandImage.img.naturalHeight || state.canvasExpandImage.img.height;
  const sourceAspect = sourceWidth / sourceHeight;
  let widthRatio = frame.widthRatio;
  let heightRatio = frame.heightRatio;

  if ((widthRatio * sourceAspect) / heightRatio < targetRatio) {
    widthRatio = heightRatio * targetRatio / sourceAspect;
  } else {
    heightRatio = widthRatio * sourceAspect / targetRatio;
  }

  state.canvasExpandFrame.widthRatio = clamp(widthRatio, 1, 4);
  state.canvasExpandFrame.heightRatio = clamp(heightRatio, 1, 4);
  state.canvasExpandFrame.xRatio = centerX - state.canvasExpandFrame.widthRatio / 2;
  state.canvasExpandFrame.yRatio = centerY - state.canvasExpandFrame.heightRatio / 2;
  normalizeCanvasExpandFrame();
  updateCanvasExpandFrameElement();
  markCanvasExpandPreviewDirty();
}

function renderCanvasExpand() {
  const item = state.canvasExpandImage;
  if (!item?.img || !els.canvasExpandCanvas) {
    setStatus("请先上传一张需要扩图的图片");
    return;
  }

  const sourceWidth = item.img.naturalWidth || item.img.width;
  const sourceHeight = item.img.naturalHeight || item.img.height;
  const plan = createCanvasExpandPlan(sourceWidth, sourceHeight, getCanvasExpandPaddingFromFrame());
  const fillColor = els.expandColorInput?.value || "#ff0000";
  const canvas = els.canvasExpandCanvas;
  canvas.width = plan.width;
  canvas.height = plan.height;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = fillColor;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(item.img, plan.imageX, plan.imageY, sourceWidth, sourceHeight);

  setCanvasExpandPreviewVisible(true);
  setCanvasExpandResolution(canvas.width, canvas.height);
  fitPreviewCanvas(canvas);
  updateCanvasExpandFrameElement();
  setStatus(`扩图完成：${canvas.width} x ${canvas.height}，尺寸已补齐为 16 的倍数`);
}

async function loadCanvasExpandFile(file) {
  if (!file || !file.type.startsWith("image/")) {
    setStatus("请选择一张需要扩图的图片");
    return;
  }

  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
  const img = await loadImageFromDataUrl(dataUrl);
  state.canvasExpandImage = {
    fileName: file.name || "canvas-expand-source.png",
    dataUrl,
    img,
  };
  state.canvasExpandFrame = {
    xRatio: -0.08,
    yRatio: -0.08,
    widthRatio: 1.16,
    heightRatio: 1.16,
  };
  state.canvasExpandViewScale = 1;

  drawImageToCanvas(els.canvasExpandSourceCanvas, img);
  if (els.canvasExpandEditor) {
    const sourceWidth = img.naturalWidth || img.width;
    const sourceHeight = img.naturalHeight || img.height;
    els.canvasExpandEditor.style.aspectRatio = `${sourceWidth} / ${sourceHeight}`;
  }
  updateCanvasExpandEditorScale();
  updateCanvasExpandFrameElement();
  if (els.canvasExpandUploadZone) els.canvasExpandUploadZone.classList.add("hasImage");
  if (els.canvasExpandUploadPrompt) els.canvasExpandUploadPrompt.style.display = "none";
  updateCanvasExpandSizePill();
  markCanvasExpandPreviewDirty();
  setStatus("已进入扩图画布编辑，可以调整方框后生成预览");
}

function clearCanvasExpand() {
  state.canvasExpandImage = null;
  state.canvasExpandViewScale = 1;
  state.canvasExpandPreviewReady = false;
  if (els.canvasExpandSourceCanvas) clearCanvas(els.canvasExpandSourceCanvas);
  if (els.canvasExpandCanvas) clearCanvas(els.canvasExpandCanvas);
  if (els.canvasExpandEditor) els.canvasExpandEditor.style.aspectRatio = "";
  updateCanvasExpandEditorScale();
  if (els.canvasExpandUploadZone) els.canvasExpandUploadZone.classList.remove("hasImage");
  if (els.canvasExpandUploadPrompt) els.canvasExpandUploadPrompt.style.display = "";
  if (els.canvasExpandEmpty) els.canvasExpandEmpty.style.display = "grid";
  updateCanvasExpandSizePill();
  setCanvasExpandResolution();
  setCanvasExpandPreviewVisible(false);
  setStatus("已清空扩图");
}

function hexToRgba(hex, alpha) {
  const normalized = String(hex || "#39ff6a").replace("#", "");
  const value = normalized.length === 3
    ? normalized.split("").map((char) => char + char).join("")
    : normalized.padEnd(6, "0").slice(0, 6);
  const red = Number.parseInt(value.slice(0, 2), 16);
  const green = Number.parseInt(value.slice(2, 4), 16);
  const blue = Number.parseInt(value.slice(4, 6), 16);
  return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
}

function applySemanticCropBoxStyle(box) {
  if (!box) return;
  box.style.setProperty("--semantic-color", state.semanticColor);
  box.classList.toggle("semanticSelected", state.semanticCropActive);
}

function updateSemanticCropHighlights() {
  document.querySelectorAll(".cropBox").forEach(applySemanticCropBoxStyle);
}

function getCrop(slice) {
  const mask = slice.mask;
  const side = Math.min(slice.width, slice.height) * (mask.sizeRatio || mask.widthRatio || 0.32);
  const baseX = slice.x + slice.width * mask.xRatio;
  const baseY = slice.y + slice.height * mask.yRatio;
  const x = clamp(Math.floor(baseX), slice.x, slice.x + slice.width - 1);
  const y = clamp(Math.floor(baseY), slice.y, slice.y + slice.height - 1);
  const right = clamp(Math.ceil(baseX + side), slice.x + 1, slice.x + slice.width);
  const bottom = clamp(Math.ceil(baseY + side), slice.y + 1, slice.y + slice.height);
  return { x, y, width: right - x, height: bottom - y };
}

function getEditedGridCell(index, img, cols = state.cols, rows = state.rows) {
  const gridCols = Math.max(1, Number.parseInt(cols, 10) || 1);
  const gridRows = Math.max(1, Number.parseInt(rows, 10) || 1);
  const col = index % gridCols;
  const row = Math.floor(index / gridCols);
  const cellWidth = img.naturalWidth / gridCols;
  const cellHeight = img.naturalHeight / gridRows;
  return {
    x: col * cellWidth,
    y: row * cellHeight,
    width: cellWidth,
    height: cellHeight,
  };
}

function sliceSource() {
  if (!state.sourceImage) {
    setStatus("璇峰厛瀵煎叆鍘熷浘");
    return;
  }

  state.cols = Math.max(1, Number.parseInt(els.colsInput.value, 10) || 2);
  state.rows = Math.max(1, Number.parseInt(els.rowsInput.value, 10) || 2);
  updateGridPresetButtons();
  state.slices = computeSlices(state.sourceImage.naturalWidth, state.sourceImage.naturalHeight, state.cols, state.rows);
  state.semanticCropActive = false;
  state.semanticCropItems = [];
  renderSliceEditors();
  clearCanvas(els.cropGridCanvas);
  setStatus(`宸插垏鎴?${state.cols} x ${state.rows}`);
}

function updateGridPresetButtons() {
  const cols = Number.parseInt(els.colsInput.value, 10) || state.cols;
  const rows = Number.parseInt(els.rowsInput.value, 10) || state.rows;
  els.gridPresetButtons.forEach((button) => {
    const buttonCols = Number.parseInt(button.dataset.cols, 10);
    const buttonRows = Number.parseInt(button.dataset.rows, 10);
    const active = buttonCols === cols && buttonRows === rows;
    button.classList.toggle("isActive", active);
    button.setAttribute("aria-pressed", String(active));
  });
}

function applyGridPreset(button) {
  const cols = Number.parseInt(button.dataset.cols, 10) || 2;
  const rows = Number.parseInt(button.dataset.rows, 10) || 2;
  els.colsInput.value = String(cols);
  els.rowsInput.value = String(rows);
  state.cols = cols;
  state.rows = rows;
  updateGridPresetButtons();
  setStatus(`已选择 ${cols} 列 ${rows} 行切片`);
}

function applySemanticMask() {
  if (!state.slices.length) {
    sliceSource();
  }

  const prompt = els.maskPrompt?.value.trim() || "闉嬪瓙";
  const lowerHint = prompt.toLowerCase();
  const focusLeft = prompt.includes("左") || lowerHint.includes("left");
  const focusRight = prompt.includes("右") || lowerHint.includes("right");
  const focusSole = prompt.includes("底") || lowerHint.includes("sole");

  state.slices.forEach((slice) => {
    if (focusLeft) {
      slice.mask.xRatio = 0.2;
      slice.mask.sizeRatio = 0.3;
    } else if (focusRight) {
      slice.mask.xRatio = 0.5;
      slice.mask.sizeRatio = 0.3;
    } else {
      slice.mask.xRatio = 0.28;
      slice.mask.sizeRatio = 0.32;
    }

    slice.mask.yRatio = focusSole ? 0.68 : 0.58;
    if (focusSole) {
      slice.mask.sizeRatio = 0.24;
    }
  });

  renderSliceCards();
  renderCropGrid();
  setStatus(`已按“${prompt || "鞋子"}”生成预估遮罩`);
}

function renderSliceEditors() {
  els.sourceCanvas.style.display = "none";
  els.emptyState.style.display = "none";
  els.sliceEditorGrid.style.display = "grid";
  els.dropZone.classList.add("editing");
  els.sliceEditorGrid.innerHTML = "";

  state.slices.forEach((slice) => {
    const editor = document.createElement("article");
    editor.className = "sliceEditor";
    editor.addEventListener("click", (event) => event.stopPropagation());

    const title = document.createElement("b");
    title.textContent = `切片 ${slice.index + 1} · 第 ${slice.row + 1} 行 第 ${slice.col + 1} 列`;

    const imageWrap = document.createElement("div");
    imageWrap.className = "sliceEditorImage";
    imageWrap.style.aspectRatio = `${slice.width} / ${slice.height}`;

    const canvas = document.createElement("canvas");
    canvas.width = slice.width;
    canvas.height = slice.height;
    canvas.getContext("2d").drawImage(
      state.sourceImage,
      slice.x,
      slice.y,
      slice.width,
      slice.height,
      0,
      0,
      slice.width,
      slice.height,
    );

    const cropBox = document.createElement("div");
    cropBox.className = "cropBox";
    const handle = document.createElement("div");
    handle.className = "cropHandle";
    cropBox.appendChild(handle);
    imageWrap.append(canvas, cropBox);
    editor.append(title, imageWrap);
    els.sliceEditorGrid.appendChild(editor);

    updateCropBox(cropBox, slice);
    applySemanticCropBoxStyle(cropBox);
    bindCropBox(cropBox, handle, imageWrap, slice);
  });
}

function updateCropBox(box, slice) {
  const mask = slice.mask;
  const minSide = Math.min(slice.width, slice.height);
  const sideX = ((minSide * mask.sizeRatio) / slice.width) * 100;
  const sideY = ((minSide * mask.sizeRatio) / slice.height) * 100;
  const left = clamp(mask.xRatio * 100, 0, 100 - sideX);
  const top = clamp(mask.yRatio * 100, 0, 100 - sideY);

  mask.xRatio = left / 100;
  mask.yRatio = top / 100;
  box.style.left = `${left}%`;
  box.style.top = `${top}%`;
  box.style.width = `${sideX}%`;
  box.style.height = `${sideY}%`;
}

function bindCropBox(box, handle, imageWrap, slice) {
  let drag = null;

  const startDrag = (event, mode) => {
    event.preventDefault();
    event.stopPropagation();
    const rect = imageWrap.getBoundingClientRect();
    drag = {
      mode,
      rect,
      startX: event.clientX,
      startY: event.clientY,
      xRatio: slice.mask.xRatio,
      yRatio: slice.mask.yRatio,
      sizeRatio: slice.mask.sizeRatio,
    };
    window.addEventListener("mousemove", moveDrag);
    window.addEventListener("mouseup", stopDrag);
  };

  const moveDrag = (event) => {
    if (!drag) return;
    const dx = (event.clientX - drag.startX) / drag.rect.width;
    const dy = (event.clientY - drag.startY) / drag.rect.height;

    if (drag.mode === "move") {
      slice.mask.xRatio = drag.xRatio + dx;
      slice.mask.yRatio = drag.yRatio + dy;
    } else {
      const pixelDelta = Math.max(
        event.clientX - drag.startX,
        event.clientY - drag.startY,
      );
      const minDisplayedSide = Math.min(drag.rect.width, drag.rect.height);
      slice.mask.sizeRatio = clamp(drag.sizeRatio + pixelDelta / minDisplayedSide, 0.06, 1);
    }

    updateCropBox(box, slice);
  };

  const stopDrag = () => {
    drag = null;
    window.removeEventListener("mousemove", moveDrag);
    window.removeEventListener("mouseup", stopDrag);
  };

  box.addEventListener("mousedown", (event) => startDrag(event, "move"));
  handle.addEventListener("mousedown", (event) => startDrag(event, "resize"));
  imageWrap.addEventListener("wheel", (event) => {
    event.preventDefault();
    const delta = event.deltaY < 0 ? 0.04 : -0.04;
    slice.mask.sizeRatio = clamp(slice.mask.sizeRatio + delta, 0.06, 1);
    updateCropBox(box, slice);
  });
}

function renderSliceCards() {
  if (!els.sliceGrid) return;

  els.sliceGrid.innerHTML = "";
  state.slices.forEach((slice) => {
    const card = document.createElement("article");
    card.className = "sliceCard";

    const title = document.createElement("b");
    title.textContent = `切片 ${slice.index + 1} · 第 ${slice.row + 1} 行 第 ${slice.col + 1} 列`;

    const wrap = document.createElement("div");
    wrap.className = "sliceCanvasWrap";
    const canvas = document.createElement("canvas");
    canvas.width = slice.width;
    canvas.height = slice.height;
    canvas.getContext("2d").drawImage(
      state.sourceImage,
      slice.x,
      slice.y,
      slice.width,
      slice.height,
      0,
      0,
      slice.width,
      slice.height,
    );
    wrap.appendChild(canvas);

    const box = document.createElement("div");
    box.className = "maskBox";
    updateMaskBox(box, slice);
    wrap.appendChild(box);

    card.append(title, wrap);
    card.append(createRange("妯悜浣嶇疆", slice.mask.xRatio, 0, 0.9, (value) => {
      slice.mask.xRatio = value;
      updateMaskBox(box, slice);
      renderCropGrid();
    }));
    card.append(createRange("绾靛悜浣嶇疆", slice.mask.yRatio, 0, 0.9, (value) => {
      slice.mask.yRatio = value;
      updateMaskBox(box, slice);
      renderCropGrid();
    }));
    card.append(createRange("鏂规澶у皬", slice.mask.widthRatio, 0.05, 1, (value) => {
      slice.mask.widthRatio = value;
      slice.mask.heightRatio = value;
      updateMaskBox(box, slice);
      renderCropGrid();
    }));
    card.append(createRange("瀹夊叏杈硅窛", slice.mask.paddingRatio, 0, 0.25, (value) => {
      slice.mask.paddingRatio = value;
      updateMaskBox(box, slice);
      renderCropGrid();
    }));

    els.sliceGrid.appendChild(card);
  });
}

function updateMaskBox(box, slice) {
  const mask = slice.mask;
  box.style.left = `${mask.xRatio * 100}%`;
  box.style.top = `${mask.yRatio * 100}%`;
  box.style.width = `${mask.widthRatio * 100}%`;
  box.style.height = `${mask.heightRatio * 100}%`;
}

function createRange(labelText, value, min, max, onInput) {
  const label = document.createElement("label");
  const span = document.createElement("span");
  const input = document.createElement("input");
  span.textContent = `${labelText}: ${Math.round(value * 100)}%`;
  input.type = "range";
  input.min = String(min);
  input.max = String(max);
  input.step = "0.01";
  input.value = String(value);
  input.addEventListener("input", () => {
    const next = Number.parseFloat(input.value);
    span.textContent = `${labelText}: ${Math.round(next * 100)}%`;
    onInput(next);
  });
  label.append(span, input);
  return label;
}

function createCropCanvas(slice, outputSize) {
  const canvas = document.createElement("canvas");
  canvas.width = outputSize;
  canvas.height = outputSize;
  const ctx = canvas.getContext("2d");
  const crop = getCrop(slice);
  ctx.drawImage(
    state.sourceImage,
    crop.x,
    crop.y,
    crop.width,
    crop.height,
    0,
    0,
    outputSize,
    outputSize,
  );
  return canvas;
}

function loadImageFromDataUrl(dataUrl) {
  return new Promise((resolve, reject) => {
    if (!dataUrl) {
      resolve(null);
      return;
    }
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

function countShoeGridImages() {
  return state.shoeGridImages.filter(Boolean).length;
}

function updateShoeGridCount() {
  if (!els.shoeGridCount) return;
  els.shoeGridCount.textContent = `${countShoeGridImages()} / 4`;
}

function setShoeGridProgress(active) {
  state.shoeGridBusy = Boolean(active);
  if (els.shoeGridProgress) els.shoeGridProgress.hidden = !active;
  if (els.directShoeGridButton) els.directShoeGridButton.disabled = Boolean(active);
  if (els.generateShoeGridButton) els.generateShoeGridButton.disabled = Boolean(active);
  if (els.shoeGridEmpty) {
    const hasOutput = els.shoeGridCanvas && els.shoeGridCanvas.width > 1 && els.shoeGridCanvas.height > 1;
    els.shoeGridEmpty.style.display = active || hasOutput ? "none" : "grid";
  }
}

function setShoeGridResolution(width = 0, height = 0) {
  if (!els.shoeGridResolution) return;
  els.shoeGridResolution.textContent = width && height ? `${Math.round(width)} x ${Math.round(height)}` : "-- x --";
}

function setActiveFeature(featureName) {
  const nextFeature = featureName === "canvasExpand"
    ? "canvasExpand"
    : featureName === "gridRemix"
    ? "gridRemix"
    : (featureName === "shoeGrid" ? "shoeGrid" : "shoeTransfer");
  state.activeFeature = nextFeature;
  document.body.dataset.featureView = nextFeature;
  els.featureButtons.forEach((button) => {
    const active = button.dataset.view === nextFeature;
    button.classList.toggle("active", active);
  });
  fitAllPreviewCanvases();
}

function findFirstEmptyShoeGridSlot() {
  const emptyIndex = state.shoeGridImages.findIndex((item) => !item);
  return emptyIndex >= 0 ? emptyIndex : 0;
}

function getShoeGridCellSize() {
  return clamp(Number.parseInt(els.shoeGridCellSizeInput?.value, 10) || 1024, 512, 2048);
}

function getDirectShoeGridCellSize() {
  const baseWidth = getShoeGridCellSize();
  const firstItem = state.shoeGridImages.find(Boolean);
  const sourceWidth = firstItem?.img?.naturalWidth || firstItem?.img?.width || baseWidth;
  const sourceHeight = firstItem?.img?.naturalHeight || firstItem?.img?.height || baseWidth;
  return {
    width: baseWidth,
    height: Math.round(baseWidth * (sourceHeight / sourceWidth)),
  };
}

function setGridRemixResolution(width = 0, height = 0) {
  if (!els.gridRemixResolution) return;
  els.gridRemixResolution.textContent = width && height ? `${Math.round(width)} x ${Math.round(height)}` : "-- x --";
}

function updateGridRemixCounts() {
  if (els.gridRemixSourceCount) {
    els.gridRemixSourceCount.textContent = `${state.gridRemixSources.length} 张`;
  }
  if (els.gridRemixSelectionCount) {
    els.gridRemixSelectionCount.textContent = `${state.gridRemixSelectedTileIds.length} / 4`;
  }
  if (els.recomposeGridButton) {
    els.recomposeGridButton.disabled = state.gridRemixSelectedTileIds.length !== 4;
  }
}

function renderGridRemixSources() {
  if (!els.gridRemixSourceList) return;
  els.gridRemixSourceList.innerHTML = "";
  state.gridRemixSources.forEach((source) => {
    const item = document.createElement("div");
    item.className = "gridRemixSourceItem";

    const canvas = document.createElement("canvas");
    canvas.width = source.img.naturalWidth || source.img.width;
    canvas.height = source.img.naturalHeight || source.img.height;
    canvas.getContext("2d").drawImage(source.img, 0, 0, canvas.width, canvas.height);

    item.appendChild(canvas);
    els.gridRemixSourceList.appendChild(item);
  });
  updateGridRemixCounts();
}

function renderGridRemixTiles() {
  if (!els.gridRemixTileList) return;
  els.gridRemixTileList.innerHTML = "";

  if (!state.gridRemixTiles.length) {
    const empty = document.createElement("div");
    empty.className = "gridRemixTileEmpty";
    empty.textContent = "涓婁紶鍥涘鏍煎悗鐐瑰嚮鑷姩鎷嗗垎";
    els.gridRemixTileList.appendChild(empty);
    updateGridRemixCounts();
    return;
  }

  state.gridRemixTiles.forEach((tile) => {
    const button = document.createElement("button");
    button.className = "gridRemixTile";
    button.type = "button";
    button.dataset.tileId = tile.id;
    const selectedIndex = state.gridRemixSelectedTileIds.indexOf(tile.id);
    button.classList.toggle("selected", selectedIndex >= 0);

    const canvas = document.createElement("canvas");
    canvas.width = tile.width;
    canvas.height = tile.height;
    canvas.getContext("2d").drawImage(tile.img, 0, 0, tile.width, tile.height);

    const meta = document.createElement("span");
    meta.textContent = selectedIndex >= 0 ? `宸查€?${selectedIndex + 1}` : tile.label;

    button.append(canvas, meta);
    button.addEventListener("click", () => toggleGridRemixTileSelection(tile.id));
    els.gridRemixTileList.appendChild(button);
  });

  updateGridRemixCounts();
}

async function loadGridRemixFiles(files) {
  const imageFiles = Array.from(files || []).filter((file) => file.type.startsWith("image/"));
  for (const file of imageFiles) {
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
    const img = await loadImageFromDataUrl(dataUrl);
    state.gridRemixSources.push({
      id: `source-${Date.now()}-${state.gridRemixSources.length}`,
      fileName: file.name || `grid-${state.gridRemixSources.length + 1}.png`,
      dataUrl,
      img,
    });
  }
  renderGridRemixSources();
  setStatus(state.gridRemixSources.length ? `已导入 ${state.gridRemixSources.length} 张四宫格图` : "请选择四宫格图片");
}

async function splitGridRemixSources() {
  if (!state.gridRemixSources.length) {
    setStatus("请先上传四宫格图像");
    return;
  }

  const tiles = [];
  for (const [sourceIndex, source] of state.gridRemixSources.entries()) {
    const width = source.img.naturalWidth || source.img.width;
    const height = source.img.naturalHeight || source.img.height;
    const leftWidth = Math.floor(width / 2);
    const rightWidth = width - leftWidth;
    const topHeight = Math.floor(height / 2);
    const bottomHeight = height - topHeight;
    const regions = [
      { x: 0, y: 0, width: leftWidth, height: topHeight, label: "宸︿笂" },
      { x: leftWidth, y: 0, width: rightWidth, height: topHeight, label: "鍙充笂" },
      { x: 0, y: topHeight, width: leftWidth, height: bottomHeight, label: "宸︿笅" },
      { x: leftWidth, y: topHeight, width: rightWidth, height: bottomHeight, label: "鍙充笅" },
    ];

    for (const [regionIndex, region] of regions.entries()) {
      const canvas = document.createElement("canvas");
      canvas.width = region.width;
      canvas.height = region.height;
      canvas.getContext("2d").drawImage(
        source.img,
        region.x,
        region.y,
        region.width,
        region.height,
        0,
        0,
        region.width,
        region.height,
      );
      const dataUrl = canvas.toDataURL("image/png");
      const img = await loadImageFromDataUrl(dataUrl);
      tiles.push({
        id: `tile-${source.id}-${regionIndex}`,
        sourceId: source.id,
        sourceName: source.fileName,
        label: `${sourceIndex + 1}-${region.label}`,
        dataUrl,
        img,
        width: region.width,
        height: region.height,
      });
    }
  }

  state.gridRemixTiles = tiles;
  state.gridRemixSelectedTileIds = [];
  if (els.gridRemixCanvas) clearCanvas(els.gridRemixCanvas);
  if (els.gridRemixEmpty) els.gridRemixEmpty.style.display = "grid";
  setGridRemixResolution();
  renderGridRemixTiles();
  setStatus(`已拆分 ${state.gridRemixSources.length} 张四宫格，得到 ${tiles.length} 张小图`);
}

function toggleGridRemixTileSelection(tileId) {
  const selectedIndex = state.gridRemixSelectedTileIds.indexOf(tileId);
  if (selectedIndex >= 0) {
    state.gridRemixSelectedTileIds.splice(selectedIndex, 1);
  } else {
    if (state.gridRemixSelectedTileIds.length >= 4) {
      setStatus("最多选择 4 张小图用于重组");
      return;
    }
    state.gridRemixSelectedTileIds.push(tileId);
  }
  renderGridRemixTiles();
}

function drawImageContain(ctx, img, x, y, width, height) {
  const sourceWidth = img.naturalWidth || img.width;
  const sourceHeight = img.naturalHeight || img.height;
  const scale = Math.min(width / sourceWidth, height / sourceHeight);
  const drawWidth = sourceWidth * scale;
  const drawHeight = sourceHeight * scale;
  ctx.drawImage(img, x + (width - drawWidth) / 2, y + (height - drawHeight) / 2, drawWidth, drawHeight);
}

function recomposeGridRemixSelection() {
  if (state.gridRemixSelectedTileIds.length !== 4) {
    setStatus("请选择 4 张拆分小图后再重组");
    return;
  }

  const selectedTiles = state.gridRemixSelectedTileIds
    .map((tileId) => state.gridRemixTiles.find((tile) => tile.id === tileId))
    .filter(Boolean);
  if (selectedTiles.length !== 4) {
    setStatus("閫変腑鐨勫皬鍥句笉瀛樺湪锛岃閲嶆柊閫夋嫨");
    return;
  }

  const cellWidth = Math.max(...selectedTiles.map((tile) => tile.width));
  const cellHeight = Math.max(...selectedTiles.map((tile) => tile.height));
  const canvas = els.gridRemixCanvas;
  canvas.width = cellWidth * 2;
  canvas.height = cellHeight * 2;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  selectedTiles.forEach((tile, index) => {
    drawImageContain(ctx, tile.img, (index % 2) * cellWidth, Math.floor(index / 2) * cellHeight, cellWidth, cellHeight);
  });

  if (els.gridRemixEmpty) els.gridRemixEmpty.style.display = "none";
  setGridRemixResolution(canvas.width, canvas.height);
  fitPreviewCanvas(canvas);
  setStatus(`宸查噸缁勫洓瀹牸锛?{canvas.width} x ${canvas.height}`);
}

function clearGridRemix() {
  state.gridRemixSources = [];
  state.gridRemixTiles = [];
  state.gridRemixSelectedTileIds = [];
  if (els.gridRemixCanvas) clearCanvas(els.gridRemixCanvas);
  if (els.gridRemixEmpty) els.gridRemixEmpty.style.display = "grid";
  setGridRemixResolution();
  renderGridRemixSources();
  renderGridRemixTiles();
  setStatus("宸叉竻绌哄洓瀹牸鎷嗗垎閲嶇粍");
}

function findMaskBoundsFromImageData(imageData, maskThreshold = 28) {
  const { data, width, height } = imageData;
  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;
  let pixels = 0;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const offset = (y * width + x) * 4;
      const maskValue = Math.max(data[offset], data[offset + 1], data[offset + 2]);
      if (maskValue <= maskThreshold) continue;
      pixels += 1;
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
    }
  }

  if (maxX < minX || maxY < minY) return null;
  return {
    x: minX,
    y: minY,
    width: maxX - minX + 1,
    height: maxY - minY + 1,
    pixels,
  };
}

function createShoeSquarePlan(sourceWidth, sourceHeight) {
  const size = Math.max(sourceWidth, sourceHeight);
  return {
    size,
    x: Math.round((size - sourceWidth) / 2),
    y: Math.round((size - sourceHeight) / 2),
    width: sourceWidth,
    height: sourceHeight,
  };
}

async function loadShoeGridFile(file, slotIndex) {
  if (!file || !file.type.startsWith("image/")) {
    setStatus("璇烽€夋嫨闉嬪瓙鍥剧墖鏂囦欢");
    return;
  }

  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
  const img = await loadImageFromDataUrl(dataUrl);
  const index = clamp(Number(slotIndex), 0, 3);

  state.shoeGridImages[index] = {
    fileName: file.name || `shoe-${index + 1}.png`,
    dataUrl,
    img,
  };
  renderShoeGridSlot(index);
  updateShoeGridCount();
  setStatus(`宸插鍏ラ瀷鍥?${index + 1}`);
}

async function loadShoeGridFiles(files, startIndex = findFirstEmptyShoeGridSlot()) {
  const imageFiles = Array.from(files || []).filter((file) => file.type.startsWith("image/")).slice(0, 4);
  let index = clamp(Number(startIndex), 0, 3);
  for (const file of imageFiles) {
    await loadShoeGridFile(file, index);
    index = (index + 1) % 4;
  }
}

function renderShoeGridSlot(index) {
  const slot = document.querySelector(`[data-shoe-slot="${index}"]`);
  const canvas = document.querySelector(`[data-shoe-canvas="${index}"]`);
  const item = state.shoeGridImages[index];
  if (!slot || !canvas) return;

  slot.classList.toggle("hasImage", Boolean(item));
  if (!item) {
    clearCanvas(canvas);
    return;
  }

  drawImageToCanvas(canvas, item.img);
}

function clearShoeGrid() {
  state.shoeGridImages = Array(4).fill(null);
  els.shoeGridSlots.forEach((slot, index) => {
    slot.classList.remove("hasImage");
    clearCanvas(document.querySelector(`[data-shoe-canvas="${index}"]`));
  });
  if (els.shoeGridCanvas) clearCanvas(els.shoeGridCanvas);
  if (els.shoeGridEmpty) els.shoeGridEmpty.style.display = "grid";
  setShoeGridResolution();
  updateShoeGridCount();
  setStatus("宸叉竻绌哄洓瀹牸闉嬪浘");
}

function directMatchShoeGrid() {
  if (countShoeGridImages() < 4) {
    setStatus("请先上传 4 张鞋图");
    return;
  }

  const { width: cellWidth, height: cellHeight } = getDirectShoeGridCellSize();
  const canvas = els.shoeGridCanvas;
  canvas.width = cellWidth * 2;
  canvas.height = cellHeight * 2;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  state.shoeGridImages.forEach((item, index) => {
    const x = (index % 2) * cellWidth;
    const y = Math.floor(index / 2) * cellHeight;
    ctx.drawImage(item.img, x, y, cellWidth, cellHeight);
  });

  setShoeGridResolution(canvas.width, canvas.height);
  if (els.shoeGridEmpty) els.shoeGridEmpty.style.display = "none";
  fitPreviewCanvas(canvas);
  setStatus(`宸茬洿鎺ュ尮閰嶅昂瀵告嫾鎴愬洓瀹牸锛?{canvas.width} x ${canvas.height}`);
  showToast(`宸茬洿鎺ユ嫾鎴愬洓瀹牸锛?{canvas.width} x ${canvas.height}`);
}

async function createSquareShoePng(item, maskDataUrl, index) {
  const mask = await loadImageFromDataUrl(maskDataUrl);
  if (!mask) throw new Error(`闉嬪浘 ${index + 1} 娌℃湁杩斿洖 mask`);

  const width = item.img.naturalWidth || item.img.width;
  const height = item.img.naturalHeight || item.img.height;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(item.img, 0, 0, width, height);

  const maskCanvas = document.createElement("canvas");
  maskCanvas.width = width;
  maskCanvas.height = height;
  const maskCtx = maskCanvas.getContext("2d");
  maskCtx.drawImage(mask, 0, 0, width, height);

  const imageData = ctx.getImageData(0, 0, width, height);
  const maskImageData = maskCtx.getImageData(0, 0, width, height);
  const maskData = maskImageData.data;
  for (let offset = 0; offset < imageData.data.length; offset += 4) {
    const maskValue = Math.max(maskData[offset], maskData[offset + 1], maskData[offset + 2]);
    imageData.data[offset + 3] = maskValue >= 28 ? imageData.data[offset + 3] : 0;
  }
  ctx.putImageData(imageData, 0, 0);

  const bounds = findMaskBoundsFromImageData(maskImageData);
  if (!bounds) throw new Error(`闉嬪浘 ${index + 1} 鐨?SAM3 閬僵涓虹┖锛岃灏濊瘯鍏抽敭璇?shoe 鎴栭噸鏂颁笂浼犳洿娓呮櫚鐨勭櫧搴曞浘`);

  const cropCanvas = document.createElement("canvas");
  cropCanvas.width = bounds.width;
  cropCanvas.height = bounds.height;
  cropCanvas.getContext("2d").drawImage(
    canvas,
    bounds.x,
    bounds.y,
    bounds.width,
    bounds.height,
    0,
    0,
    bounds.width,
    bounds.height,
  );

  const square = createShoeSquarePlan(bounds.width, bounds.height);
  const squareCanvas = document.createElement("canvas");
  squareCanvas.width = square.size;
  squareCanvas.height = square.size;
  squareCanvas.getContext("2d").drawImage(cropCanvas, square.x, square.y, square.width, square.height);
  return squareCanvas;
}

async function generateShoeGrid() {
  if (countShoeGridImages() < 4) {
    setStatus("请先上传 4 张白底鞋图");
    return;
  }

  const prompt = (els.shoeGridPromptInput?.value || "shoe").trim() || "shoe";
  const cellSize = getShoeGridCellSize();
  const rawItems = state.shoeGridImages.map((item, index) => ({
    index,
    row: Math.floor(index / 2),
    col: index % 2,
    dataUrl: item.dataUrl,
  }));

  setShoeGridProgress(true);
  setStatus(`姝ｅ湪鐢?SAM3 璇嗗埆鈥?{prompt}鈥濆苟鐢熸垚鏃犵紳 JPG 鍥涘鏍?..`);
  try {
    const response = await window.shoeTransfer.segmentSemanticCrops({
      prompt,
      items: rawItems,
    });
    if (!response?.ok) {
      throw new Error(response?.reason || "SAM3 璇嗗埆澶辫触");
    }
    const missingMaskIndex = (response.items || []).findIndex((item) => !item?.maskDataUrl);
    if (missingMaskIndex >= 0) {
      throw new Error(`闉嬪浘 ${missingMaskIndex + 1} 娌℃湁鎷垮埌 SAM3 閬僵`);
    }

    const canvas = els.shoeGridCanvas;
    canvas.width = cellSize * 2;
    canvas.height = cellSize * 2;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let index = 0; index < 4; index += 1) {
      const result = response.items?.[index];
      const squareCanvas = await createSquareShoePng(state.shoeGridImages[index], result?.maskDataUrl, index);
      const x = (index % 2) * cellSize;
      const y = Math.floor(index / 2) * cellSize;
      ctx.drawImage(squareCanvas, x, y, cellSize, cellSize);
    }

    setShoeGridResolution(canvas.width, canvas.height);
    if (els.shoeGridEmpty) els.shoeGridEmpty.style.display = "none";
    fitPreviewCanvas(canvas);
    setStatus(`宸茬敓鎴愭棤缂濆洓瀹牸 JPG锛?{canvas.width} x ${canvas.height}`);
    showToast(`宸茬敓鎴愬洓瀹牸锛?{canvas.width} x ${canvas.height}`);
  } catch (error) {
    setStatus(`鍥涘鏍肩敓鎴愬け璐ワ細${error.message}`);
    showToast(`鐢熸垚澶辫触锛?{error.message}`);
  } finally {
    setShoeGridProgress(false);
  }
}

async function exportShoeGridImage() {
  if (!els.shoeGridCanvas?.width || els.shoeGridCanvas.width <= 1) {
    setStatus("请先生成四宫格图片");
    return;
  }

  const target = els.shoeGridSavePathInput?.value.trim() || "";
  if (target && window.shoeTransfer?.savePng) {
    try {
      const outputPath = await window.shoeTransfer.savePng({
        dataUrl: els.shoeGridCanvas.toDataURL(SHOE_GRID_EXPORT_MIME, SHOE_GRID_EXPORT_QUALITY),
        filename: SHOE_GRID_EXPORT_NAME,
        target,
      });
      setStatus(`宸蹭繚瀛樺埌 ${outputPath}`);
      showToast("四宫格 JPG 已保存");
      return;
    } catch (error) {
      setStatus(`淇濆瓨澶辫触锛?{error.message}`);
      return;
    }
  }

  const link = document.createElement("a");
  link.download = SHOE_GRID_EXPORT_NAME;
  link.href = els.shoeGridCanvas.toDataURL(SHOE_GRID_EXPORT_MIME, SHOE_GRID_EXPORT_QUALITY);
  link.click();
}

async function openShoeGridFolder() {
  const target = els.shoeGridSavePathInput?.value.trim() || "";
  if (!target) {
    setStatus("请先填写本地保存文件夹路径");
    return;
  }

  try {
    await window.shoeTransfer.openPath(target);
  } catch (error) {
    setStatus(`鎵撳紑鏂囦欢澶瑰け璐ワ細${error.message}`);
  }
}

function expandSemanticMask(maskBits, width, height, expandPixels) {
  const radius = clamp(Number.parseInt(expandPixels, 10) || 0, 0, 64);
  if (radius <= 0) return maskBits;

  const stride = width + 1;
  const integral = new Uint32Array((width + 1) * (height + 1));
  for (let y = 0; y < height; y += 1) {
    let rowTotal = 0;
    for (let x = 0; x < width; x += 1) {
      rowTotal += maskBits[y * width + x];
      const target = (y + 1) * stride + x + 1;
      integral[target] = integral[target - stride] + rowTotal;
    }
  }

  const expanded = new Uint8Array(maskBits.length);
  for (let y = 0; y < height; y += 1) {
    const y1 = Math.max(0, y - radius);
    const y2 = Math.min(height, y + radius + 1);
    for (let x = 0; x < width; x += 1) {
      const x1 = Math.max(0, x - radius);
      const x2 = Math.min(width, x + radius + 1);
      const count = integral[y2 * stride + x2]
        - integral[y1 * stride + x2]
        - integral[y2 * stride + x1]
        + integral[y1 * stride + x1];
      if (count > 0) expanded[y * width + x] = 1;
    }
  }
  return expanded;
}

function createSemanticMaskAlpha(maskBits, width, height, featherPixels) {
  const feather = clamp(Number.parseInt(featherPixels, 10) || 0, 0, 64);
  const imageData = new ImageData(width, height);
  for (let index = 0; index < maskBits.length; index += 1) {
    imageData.data[index * 4 + 3] = maskBits[index] ? 255 : 0;
  }

  if (feather <= 0) return imageData.data;

  const maskCanvas = document.createElement("canvas");
  maskCanvas.width = width;
  maskCanvas.height = height;
  maskCanvas.getContext("2d").putImageData(imageData, 0, 0);

  const featherCanvas = document.createElement("canvas");
  featherCanvas.width = width;
  featherCanvas.height = height;
  const featherCtx = featherCanvas.getContext("2d");
  featherCtx.filter = `blur(${feather}px)`;
  featherCtx.drawImage(maskCanvas, 0, 0);
  return featherCtx.getImageData(0, 0, width, height).data;
}

function updateSemanticOpacityValue() {
  const opacity = clamp(Number.parseFloat(els.semanticOpacityInput?.value) || 1, 0.1, 1);
  state.semanticOpacity = opacity;
  if (els.semanticOpacityInput) {
    els.semanticOpacityInput.style.setProperty("--range-fill", `${Math.round(opacity * 100)}%`);
  }
  if (els.semanticOpacityValue) {
    els.semanticOpacityValue.textContent = `${Math.round(opacity * 100)}%`;
  }
}

function updateSemanticControlState() {
  state.semanticColor = els.semanticColorInput.value || "#39ff6a";
  updateSemanticOpacityValue();
  state.semanticExpand = clamp(Number.parseInt(els.semanticExpandInput?.value, 10) || 0, 0, 64);
  state.semanticFeather = clamp(Number.parseInt(els.semanticFeatherInput?.value, 10) || 0, 0, 64);
}

async function applySemanticMaskToCrop(cropCanvas, maskDataUrl, color, options = {}) {
  if (!maskDataUrl) return cropCanvas;

  const mask = await loadImageFromDataUrl(maskDataUrl);
  if (!mask) return cropCanvas;

  const output = document.createElement("canvas");
  output.width = cropCanvas.width;
  output.height = cropCanvas.height;
  const ctx = output.getContext("2d");
  ctx.drawImage(cropCanvas, 0, 0);

  const maskCanvas = document.createElement("canvas");
  maskCanvas.width = cropCanvas.width;
  maskCanvas.height = cropCanvas.height;
  const maskCtx = maskCanvas.getContext("2d");
  maskCtx.drawImage(mask, 0, 0, maskCanvas.width, maskCanvas.height);
  const maskPixels = maskCtx.getImageData(0, 0, maskCanvas.width, maskCanvas.height).data;

  const overlay = ctx.getImageData(0, 0, output.width, output.height);
  const colorMatch = String(color || "#39ff6a").match(/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i);
  const red = colorMatch ? Number.parseInt(colorMatch[1], 16) : 57;
  const green = colorMatch ? Number.parseInt(colorMatch[2], 16) : 255;
  const blue = colorMatch ? Number.parseInt(colorMatch[3], 16) : 106;
  const alphaValue = Number.parseFloat(options.opacity);
  const alpha = clamp(Number.isFinite(alphaValue) ? alphaValue : state.semanticOpacity, 0.1, 1);
  const expandPixels = Number.isFinite(Number(options.expandPixels)) ? options.expandPixels : state.semanticExpand;
  const featherPixels = Number.isFinite(Number(options.featherPixels)) ? options.featherPixels : state.semanticFeather;

  const totalMaskPixels = maskCanvas.width * maskCanvas.height;
  const maskBits = new Uint8Array(totalMaskPixels);
  for (let index = 0; index < maskPixels.length; index += 4) {
    const maskValue = Math.max(maskPixels[index], maskPixels[index + 1], maskPixels[index + 2]);
    if (maskValue >= 28) maskBits[index / 4] = 1;
  }

  const expandedMask = expandSemanticMask(maskBits, maskCanvas.width, maskCanvas.height, expandPixels);
  let activeMaskPixels = 0;
  for (let index = 0; index < expandedMask.length; index += 1) {
    activeMaskPixels += expandedMask[index];
  }

  const maskCoverage = activeMaskPixels / Math.max(totalMaskPixels, 1);
  if (maskCoverage <= 0 || maskCoverage > MAX_SEMANTIC_MASK_RATIO) {
    return cropCanvas;
  }

  const maskAlpha = createSemanticMaskAlpha(expandedMask, maskCanvas.width, maskCanvas.height, featherPixels);
  for (let index = 0; index < overlay.data.length; index += 4) {
    const maskWeight = maskAlpha[index + 3] / 255;
    if (maskWeight <= 0) continue;
    const weightedAlpha = alpha * maskWeight;
    overlay.data[index] = Math.round(overlay.data[index] * (1 - weightedAlpha) + red * weightedAlpha);
    overlay.data[index + 1] = Math.round(overlay.data[index + 1] * (1 - weightedAlpha) + green * weightedAlpha);
    overlay.data[index + 2] = Math.round(overlay.data[index + 2] * (1 - weightedAlpha) + blue * weightedAlpha);
  }

  ctx.putImageData(overlay, 0, 0);
  return output;
}

function renderCropGrid() {
  if (!state.sourceImage || !state.slices.length) return;

  const outputSize = clamp(Number.parseInt(els.cropSizeInput.value, 10) || 1024, 256, 2048);
  const canvas = els.cropGridCanvas;
  canvas.width = state.cols * outputSize;
  canvas.height = state.rows * outputSize;
  els.cropEmpty.style.display = "none";
  setCropResolution(canvas.width, canvas.height);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#eef1f5";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  state.slices.forEach((slice) => {
    const cropCanvas = createCropCanvas(slice, outputSize);
    ctx.drawImage(cropCanvas, slice.col * outputSize, slice.row * outputSize);
  });
  fitPreviewCanvas(canvas);
}

async function paintSemanticCropGrid(items, outputSize) {
  const canvas = els.cropGridCanvas;
  canvas.width = state.cols * outputSize;
  canvas.height = state.rows * outputSize;
  els.cropEmpty.style.display = "none";
  setCropResolution(canvas.width, canvas.height);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#eef1f5";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (const item of items) {
    const cropCanvas = document.createElement("canvas");
    cropCanvas.width = outputSize;
    cropCanvas.height = outputSize;
    const cropCtx = cropCanvas.getContext("2d");
    const source = await loadImageFromDataUrl(item.dataUrl);
    cropCtx.drawImage(source, 0, 0, outputSize, outputSize);
    const colored = await applySemanticMaskToCrop(cropCanvas, item.maskDataUrl, state.semanticColor, {
      opacity: state.semanticOpacity,
      expandPixels: state.semanticExpand,
      featherPixels: state.semanticFeather,
    });
    ctx.drawImage(colored, item.col * outputSize, item.row * outputSize);
  }

  fitPreviewCanvas(canvas);
  setEditedImageFromCanvas(canvas);
}

async function repaintSemanticCropGrid() {
  if (!state.semanticCropItems.length) return;
  const outputSize = clamp(Number.parseInt(els.cropSizeInput.value, 10) || 1024, 256, 2048);
  await paintSemanticCropGrid(state.semanticCropItems, outputSize);
}

async function renderSemanticCropGrid() {
  if (!state.sourceImage || !state.slices.length) return { ok: false, reason: "no-slices" };

  updateSemanticControlState();
  const outputSize = clamp(Number.parseInt(els.cropSizeInput.value, 10) || 1024, 256, 2048);
  const rawItems = state.slices.map((slice) => {
    const cropCanvas = createCropCanvas(slice, outputSize);
    return {
      index: slice.index,
      row: slice.row,
      col: slice.col,
      dataUrl: cropCanvas.toDataURL("image/png"),
    };
  });

  const response = await window.shoeTransfer.segmentSemanticCrops({
    prompt: state.semanticPrompt,
    color: state.semanticColor,
    items: rawItems,
  });

  state.semanticCropItems = response.items || rawItems;
  await paintSemanticCropGrid(state.semanticCropItems, outputSize);
  return response;
}

function confirmCropSelection() {
  if (!state.sourceImage || !state.slices.length) {
    setStatus("请先导入原图并开始切片");
    return;
  }

  renderCropGrid();
  const outputSize = Number.parseInt(els.cropSizeInput.value, 10) || 1024;
  setStatus(`宸茬洿鎺ヨ鍓細姣忓紶 ${outputSize} x ${outputSize}`);
}

async function confirmSemanticCropSelection() {
  if (!state.sourceImage || !state.slices.length) {
    setStatus("请先导入原图并开始切片");
    return;
  }

  const prompt = els.semanticPromptInput.value.trim();
  if (!prompt) {
    els.semanticPromptInput.focus();
    setStatus("璇疯緭鍏ヨ涔夊叧閿瘝锛屼緥濡傦細闉嬪瓙銆佽。鏈嶃€佸寘");
    return;
  }

  state.semanticPrompt = prompt;
  updateSemanticControlState();
  state.semanticCropActive = true;
  updateSemanticCropHighlights();
  setStatus(`姝ｅ湪鐢ㄥ唴缃?SAM3 璇嗗埆鈥?{prompt}鈥濆尯鍩?..`);
  setSemanticProgress(true);
  els.confirmCropButton.disabled = true;

  try {
    const response = await renderSemanticCropGrid();
    const outputSize = Number.parseInt(els.cropSizeInput.value, 10) || 1024;
    if (response?.ok) {
      setStatus(`宸叉寜鈥?{prompt}鈥濊瘑鍒苟鍙粰鐩爣鍖哄煙涓婅壊锛氭瘡寮?${outputSize} x ${outputSize}`);
      return;
    }

    setStatus(`已生成原始裁剪图，但内置 SAM3 未返回 mask：${response?.reason || "请确认软件内置模型完整"}`);
  } catch (error) {
    setStatus(`璇箟瑁佸壀澶辫触锛?{error.message}`);
  } finally {
    els.confirmCropButton.disabled = false;
    setSemanticProgress(false);
  }
}

function drawFullEditedCellToCrop(ctx, slice, index) {
  const crop = getCrop(slice);
  const editedCell = getEditedGridCell(index, state.editedImage, state.cols, state.rows);
  ctx.drawImage(
    state.editedImage,
    editedCell.x,
    editedCell.y,
    editedCell.width,
    editedCell.height,
    crop.x,
    crop.y,
    crop.width,
    crop.height,
  );
}

async function pasteEditedCellToCrop(ctx, slice, index) {
  const crop = getCrop(slice);
  const editedCell = getEditedGridCell(index, state.editedImage, state.cols, state.rows);
  const semanticItem = state.semanticCropItems.find((item) => item.index === slice.index && item.maskDataUrl);

  if (!semanticItem) {
    drawFullEditedCellToCrop(ctx, slice, index);
    return;
  }

  try {
    const mask = await loadImageFromDataUrl(semanticItem.maskDataUrl);
    if (!mask) {
      drawFullEditedCellToCrop(ctx, slice, index);
      return;
    }

    const pasteCanvas = document.createElement("canvas");
    pasteCanvas.width = Math.max(1, Math.round(crop.width));
    pasteCanvas.height = Math.max(1, Math.round(crop.height));
    const pasteCtx = pasteCanvas.getContext("2d");
    pasteCtx.drawImage(
      state.editedImage,
      editedCell.x,
      editedCell.y,
      editedCell.width,
      editedCell.height,
      0,
      0,
      pasteCanvas.width,
      pasteCanvas.height,
    );
    pasteCtx.globalCompositeOperation = "destination-in";
    pasteCtx.drawImage(mask, 0, 0, pasteCanvas.width, pasteCanvas.height);
    pasteCtx.globalCompositeOperation = "source-over";
    ctx.drawImage(pasteCanvas, crop.x, crop.y, crop.width, crop.height);
  } catch (error) {
    drawFullEditedCellToCrop(ctx, slice, index);
  }
}

async function pasteBack() {
  if (!state.sourceImage || !state.slices.length) {
    setStatus("请先导入并切片原图");
    return false;
  }
  if (!state.editedImage) {
    setStatus("请先导入换鞋后的结果图");
    return false;
  }

  const expectedSliceCount = state.cols * state.rows;
  if (state.slices.length < expectedSliceCount) {
    setStatus(`璇峰厛鎸?${state.cols} x ${state.rows} 瀹屾垚鍒囩墖閫夊尯`);
    return false;
  }

  const canvas = els.finalCanvas;
  canvas.width = state.sourceImage.naturalWidth;
  canvas.height = state.sourceImage.naturalHeight;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(state.sourceImage, 0, 0, canvas.width, canvas.height);

  const pasteSlices = state.slices.slice(0, expectedSliceCount);
  for (const [index, slice] of pasteSlices.entries()) {
    await pasteEditedCellToCrop(ctx, slice, index);
  }

  els.finalEmpty.style.display = "none";
  fitPreviewCanvas(canvas);
  setStatus("已贴回原图，可以导出最终图片");
  return true;
}

async function exportFinalImage() {
  const pasted = await pasteBack();
  if (!pasted) return;

  await exportFinalSlices();
}

async function openSaveFolder() {
  const targetPath = els.savePathInput.value.trim();
  if (!targetPath) {
    showToast("璇峰厛濉啓淇濆瓨璺緞");
    return;
  }

  persistSavePathIfLocked();
  try {
    const openedPath = await window.shoeTransfer.openPath(targetPath);
    showToast(`宸叉墦寮€鏂囦欢澶癸細${openedPath}`);
  } catch (error) {
    showToast(`鎵撳紑鏂囦欢澶瑰け璐ワ細${error.message}`);
  }
}

async function openImageViewer() {
  if (els.finalCanvas.width <= 1 || els.finalCanvas.height <= 1) {
    const pasted = await pasteBack();
    if (!pasted) return;
  }

  els.imageViewerOverlay.hidden = false;
  copyCanvasToCanvas(els.finalCanvas, els.viewerCanvas);
}

function closeImageViewer() {
  els.imageViewerOverlay.hidden = true;
}

async function exportFinalSlices() {
  const targetPath = els.savePathInput.value.trim();
  if (!targetPath) {
    setStatus("请先填写本地保存文件夹路径");
    return;
  }

  const items = state.slices.map((slice) => {
    const sliceCanvas = document.createElement("canvas");
    sliceCanvas.width = slice.width;
    sliceCanvas.height = slice.height;
    const ctx = sliceCanvas.getContext("2d");
    ctx.drawImage(
      els.finalCanvas,
      slice.x,
      slice.y,
      slice.width,
      slice.height,
      0,
      0,
      slice.width,
      slice.height,
    );
    return {
      filename: `final-slice-${slice.index + 1}-row${slice.row + 1}-col${slice.col + 1}.jpg`,
      dataUrl: sliceCanvas.toDataURL("image/jpeg", 0.94),
    };
  });

  try {
    const saved = await window.shoeTransfer.savePngList({
      target: targetPath,
      items,
    });
    setStatus(`已导出 ${saved.length} 张切片到本地文件夹`);
    showToast(`导出成功：已保存 ${saved.length} 张图片`);
  } catch (error) {
    setStatus(`瀵煎嚭鍒囩墖澶辫触锛?{error.message}`);
  }
}

async function downloadCanvas(canvas, name, targetPath = "") {
  if (!canvas.width || !canvas.height) {
    setStatus("娌℃湁鍙鍑虹殑鍥剧墖");
    return;
  }
  if (targetPath.trim() && window.shoeTransfer?.savePng) {
    try {
      const outputPath = await window.shoeTransfer.savePng({
        dataUrl: canvas.toDataURL("image/jpeg", 0.94),
        filename: name,
        target: targetPath.trim(),
      });
      setStatus(`宸蹭繚瀛樺埌 ${outputPath}`);
      return;
    } catch (error) {
      setStatus(`淇濆瓨澶辫触锛?{error.message}`);
      return;
    }
  }

  const link = document.createElement("a");
  link.download = name;
  link.href = canvas.toDataURL("image/jpeg", 0.94);
  link.click();
}

async function copyCanvasToClipboard(canvas) {
  if (!canvas.width || !canvas.height) {
    setStatus("娌℃湁鍙鍒剁殑鍥剧墖");
    return;
  }

  try {
    await window.shoeTransfer.copyPng(canvas.toDataURL("image/png"));
    setStatus("图片已复制到剪贴板");
  } catch (error) {
    setStatus(`澶嶅埗澶辫触锛?{error.message}`);
  }
}

function clearCropImage() {
  clearCanvas(els.cropGridCanvas);
  els.cropEmpty.style.display = "grid";
  setCropResolution();
  setStatus("宸插垹闄や腑闂村浘");
}

function clearFinalImage() {
  clearCanvas(els.finalCanvas);
  els.finalEmpty.style.display = "grid";
  setStatus("宸插垹闄ゆ渶缁堝浘");
}

function fitDoodleCanvasToShell() {
  const canvas = els.doodleCanvas;
  const rect = els.doodleCanvasShell.getBoundingClientRect();
  if (!canvas.width || !canvas.height || !rect.width || !rect.height) return;
  const scale = Math.min(rect.width / canvas.width, rect.height / canvas.height);
  canvas.style.width = `${Math.floor(canvas.width * scale)}px`;
  canvas.style.height = `${Math.floor(canvas.height * scale)}px`;
}

function captureDoodleSnapshot() {
  const canvas = els.doodleCanvas;
  if (!canvas.width || !canvas.height) return null;
  return canvas.getContext("2d").getImageData(0, 0, canvas.width, canvas.height);
}

function updateDoodleHistoryButtons() {
  const canUndo = state.doodleHistoryIndex > 0;
  const canRedo = state.doodleHistoryIndex >= 0 && state.doodleHistoryIndex < state.doodleHistory.length - 1;
  els.undoDoodleButton.disabled = !canUndo;
  els.redoDoodleButton.disabled = !canRedo;
}

function pushDoodleHistory() {
  const snapshot = captureDoodleSnapshot();
  if (!snapshot) return;

  state.doodleHistory = state.doodleHistory.slice(0, state.doodleHistoryIndex + 1);
  state.doodleHistory.push(snapshot);
  if (state.doodleHistory.length > DOODLE_HISTORY_LIMIT) {
    state.doodleHistory.shift();
  }
  state.doodleHistoryIndex = state.doodleHistory.length - 1;
  updateDoodleHistoryButtons();
}

function restoreDoodleHistory(index) {
  const snapshot = state.doodleHistory[index];
  if (!snapshot) return;
  els.doodleCanvas.getContext("2d").putImageData(snapshot, 0, 0);
  state.doodleHistoryIndex = index;
  updateDoodleHistoryButtons();
}

function undoDoodle() {
  if (state.doodleHistoryIndex <= 0) return;
  restoreDoodleHistory(state.doodleHistoryIndex - 1);
}

function redoDoodle() {
  if (state.doodleHistoryIndex >= state.doodleHistory.length - 1) return;
  restoreDoodleHistory(state.doodleHistoryIndex + 1);
}

function resetDoodleHistory() {
  state.doodleHistory = [];
  state.doodleHistoryIndex = -1;
  pushDoodleHistory();
}

function openDoodleBoard(targetCanvas) {
  if (!targetCanvas.width || !targetCanvas.height) {
    setStatus("请先导入或生成图片，再进入涂鸦画板");
    return;
  }

  state.doodleTarget = targetCanvas;
  state.lastDoodlePoint = null;
  els.doodleOverlay.hidden = false;
  const canvas = els.doodleCanvas;
  canvas.width = targetCanvas.width;
  canvas.height = targetCanvas.height;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#111827";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(targetCanvas, 0, 0, canvas.width, canvas.height);
  fitDoodleCanvasToShell();
  resetDoodleHistory();
}

function getCanvasPoint(event) {
  const rect = els.doodleCanvas.getBoundingClientRect();
  return {
    x: ((event.clientX - rect.left) / rect.width) * els.doodleCanvas.width,
    y: ((event.clientY - rect.top) / rect.height) * els.doodleCanvas.height,
  };
}

function paintAt(event) {
  if (!state.doodling) return;
  const ctx = els.doodleCanvas.getContext("2d");
  const point = getCanvasPoint(event);
  const last = state.lastDoodlePoint || point;
  const smooth = (Number.parseInt(els.brushSmoothInput.value, 10) || 0) / 100;
  const x = last.x + (point.x - last.x) * (1 - smooth * 0.65);
  const y = last.y + (point.y - last.y) * (1 - smooth * 0.65);
  const opacity = (Number.parseInt(els.brushOpacityInput.value, 10) || 100) / 100;
  ctx.save();
  ctx.globalAlpha = opacity;
  ctx.strokeStyle = els.brushColorInput.value;
  ctx.lineWidth = Number.parseInt(els.brushSizeInput.value, 10) || 24;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(last.x, last.y);
  ctx.lineTo(x, y);
  ctx.stroke();
  ctx.restore();
  state.lastDoodlePoint = { x, y };
}

function saveDoodleBoard() {
  if (!state.doodleTarget) return;
  const canvas = state.doodleTarget;
  canvas.width = els.doodleCanvas.width;
  canvas.height = els.doodleCanvas.height;
  canvas.getContext("2d").drawImage(els.doodleCanvas, 0, 0);
  if (canvas === els.cropGridCanvas) {
    setEditedImageFromCanvas(canvas);
  }
  if (canvas === els.finalCanvas) {
    els.finalEmpty.style.display = "none";
  }
  fitPreviewCanvas(canvas);
  els.doodleOverlay.hidden = true;
  state.doodleTarget = null;
  state.doodleHistory = [];
  state.doodleHistoryIndex = -1;
  updateDoodleHistoryButtons();
  setStatus("涂鸦已保存");
}

setupCustomCursor();
bindCanvasExpandFrame();
els.sourceInput.addEventListener("change", (event) => loadImageFromFile(event.target.files[0]));
setTheme(localStorage.getItem("shoe-transfer-theme") || "light");
restoreSavePathLock();
setActiveModule(state.activeModule);
setActiveFeature(state.activeFeature);
els.modulePanels.forEach((panel) => {
  panel.addEventListener("click", (event) => {
    if (!panel.classList.contains("moduleLocked")) return;
    event.preventDefault();
    event.stopPropagation();
    setActiveModule(panel.dataset.module);
  });
});
els.themeOptions.forEach((button) => {
  button.addEventListener("click", () => setTheme(button.dataset.themeOption));
});
els.dropZone.addEventListener("click", (event) => {
  if (els.dropZone.classList.contains("editing")) return;
  if (event.target.closest(".cropBar")) return;
  els.sourceInput.click();
});
els.sidebarToggle.addEventListener("click", () => els.app.classList.toggle("sidebarCollapsed"));
els.featureButtons.forEach((button) => {
  button.addEventListener("click", () => {
    if (button.dataset.view === "shoeGrid") {
      setActiveFeature("shoeGrid");
      setStatus(countShoeGridImages() ? "可以继续上传鞋图或生成四宫格" : "等待上传 4 张白底鞋图");
      return;
    }
    if (button.dataset.view === "gridRemix") {
      setActiveFeature("gridRemix");
      setStatus(state.gridRemixTiles.length ? "请选择 4 张小图重组四宫格" : "等待上传四宫格图像");
      return;
    }
    if (button.dataset.view === "canvasExpand") {
      setActiveFeature("canvasExpand");
      setStatus(state.canvasExpandImage ? "可以调整扩展尺寸和底色" : "等待上传一张需要扩图的图片");
      return;
    }
    setActiveFeature("shoeTransfer");
    if (button.dataset.view === "comingSoon") {
      setStatus("棰勭暀鍔熻兘椤靛緟娣诲姞");
    } else {
      setStatus(state.sourceImage ? "鍘熷浘宸插鍏ワ紝鍙互璁剧疆鍒囩墖" : "绛夊緟瀵煎叆鍥剧墖");
    }
  });
});
els.shoeGridSlots.forEach((slot) => {
  slot.addEventListener("click", () => {
    state.shoeGridInputIndex = Number.parseInt(slot.dataset.shoeSlot, 10) || 0;
    els.shoeGridInput.click();
  });
  slot.addEventListener("dragover", (event) => {
    event.preventDefault();
    slot.classList.add("dragging");
  });
  slot.addEventListener("dragleave", () => slot.classList.remove("dragging"));
  slot.addEventListener("drop", (event) => {
    event.preventDefault();
    slot.classList.remove("dragging");
    const index = Number.parseInt(slot.dataset.shoeSlot, 10) || 0;
    loadShoeGridFiles(event.dataTransfer.files, index);
  });
});
els.shoeGridInput.addEventListener("change", (event) => {
  loadShoeGridFiles(event.target.files, state.shoeGridInputIndex);
  event.target.value = "";
});
els.gridRemixUploadZone.addEventListener("click", () => els.gridRemixInput.click());
els.gridRemixUploadZone.addEventListener("dragover", (event) => {
  event.preventDefault();
  els.gridRemixUploadZone.classList.add("dragging");
});
els.gridRemixUploadZone.addEventListener("dragleave", () => els.gridRemixUploadZone.classList.remove("dragging"));
els.gridRemixUploadZone.addEventListener("drop", (event) => {
  event.preventDefault();
  els.gridRemixUploadZone.classList.remove("dragging");
  loadGridRemixFiles(event.dataTransfer.files);
});
els.gridRemixInput.addEventListener("change", (event) => {
  loadGridRemixFiles(event.target.files);
  event.target.value = "";
});
els.canvasExpandUploadZone.addEventListener("click", () => {
  if (state.canvasExpandImage) return;
  els.canvasExpandInput.click();
});
els.canvasExpandUploadZone.addEventListener("wheel", (event) => {
  if (!state.canvasExpandImage) return;
  if (event.target.closest("#canvasExpandFrame") || event.target === els.canvasExpandSourceCanvas) return;
  event.preventDefault();
  event.stopPropagation();
  const scale = event.deltaY < 0 ? 1.08 : 0.92;
  state.canvasExpandViewScale = clamp(state.canvasExpandViewScale * scale, 0.45, 2.8);
  updateCanvasExpandEditorScale();
}, { passive: false });
els.canvasExpandUploadZone.addEventListener("dragover", (event) => {
  event.preventDefault();
  els.canvasExpandUploadZone.classList.add("dragging");
});
els.canvasExpandUploadZone.addEventListener("dragleave", () => els.canvasExpandUploadZone.classList.remove("dragging"));
els.canvasExpandUploadZone.addEventListener("drop", (event) => {
  event.preventDefault();
  els.canvasExpandUploadZone.classList.remove("dragging");
  loadCanvasExpandFile(event.dataTransfer.files?.[0]);
});
els.canvasExpandInput.addEventListener("change", (event) => {
  loadCanvasExpandFile(event.target.files?.[0]);
  event.target.value = "";
});
[els.expandColorInput].forEach((input) => {
  input.addEventListener("input", () => {
    if (state.canvasExpandImage) markCanvasExpandPreviewDirty();
  });
});
els.canvasExpandReturnButton.addEventListener("click", clearCanvasExpand);
els.canvasExpandRatioButton.addEventListener("click", (event) => {
  event.stopPropagation();
  els.canvasExpandRatioMenu.hidden = !els.canvasExpandRatioMenu.hidden;
});
els.canvasExpandRatioButtons.forEach((button) => {
  button.addEventListener("click", (event) => {
    event.stopPropagation();
    applyCanvasExpandRatio(button.dataset.expandRatio);
    els.canvasExpandRatioMenu.hidden = true;
  });
});
document.addEventListener("click", (event) => {
  if (!event.target.closest(".canvasExpandRatioPicker")) {
    els.canvasExpandRatioMenu.hidden = true;
  }
});
els.renderCanvasExpandButton.addEventListener("click", renderCanvasExpand);
els.clearCanvasExpandButton.addEventListener("click", clearCanvasExpand);
els.finalInput.addEventListener("change", (event) => loadFinalImageFromFile(event.target.files[0]));
els.finalDropZone.addEventListener("click", () => {
  els.finalInput.click();
});
els.returnUploadButton.addEventListener("click", returnToSourceUpload);
els.gridPresetButtons.forEach((button) => {
  button.addEventListener("click", () => applyGridPreset(button));
});
els.colsInput.addEventListener("input", updateGridPresetButtons);
els.rowsInput.addEventListener("input", updateGridPresetButtons);
els.sliceButton.addEventListener("click", sliceSource);
els.directCropButton.addEventListener("click", () => {
  if (!state.slices.length) sliceSource();
  confirmCropSelection();
});
els.confirmCropButton.addEventListener("click", confirmSemanticCropSelection);
els.semanticColorInput.addEventListener("input", () => {
  updateSemanticControlState();
  updateSemanticCropHighlights();
  if (state.semanticCropActive) repaintSemanticCropGrid();
});
els.semanticOpacityInput.addEventListener("input", () => {
  updateSemanticControlState();
  if (state.semanticCropActive) repaintSemanticCropGrid();
});
els.semanticExpandInput.addEventListener("input", () => {
  updateSemanticControlState();
  if (state.semanticCropActive) repaintSemanticCropGrid();
});
els.semanticFeatherInput.addEventListener("input", () => {
  updateSemanticControlState();
  if (state.semanticCropActive) repaintSemanticCropGrid();
});
if (els.detectButton) {
  els.detectButton.addEventListener("click", applySemanticMask);
}
els.exportCropButton.addEventListener("click", () => {
  if (!state.slices.length) sliceSource();
  confirmCropSelection();
  downloadCanvas(els.cropGridCanvas, "nanobanana-shoe-crops-2k.jpg");
});
els.copyCropButton.addEventListener("click", () => copyCanvasToClipboard(els.cropGridCanvas));
els.openCropEditorButton.addEventListener("click", () => openDoodleBoard(els.cropGridCanvas));
els.pasteBackButton.addEventListener("click", pasteBack);
els.viewFinalButton.addEventListener("click", openImageViewer);
els.downloadFinalButton.addEventListener("click", exportFinalImage);
els.openSaveFolderButton.addEventListener("click", openSaveFolder);
els.savePathInput.addEventListener("input", persistSavePathIfLocked);
els.savePathLockButton.addEventListener("click", () => {
  setSavePathLocked(!els.savePathLockButton.classList.contains("locked"));
});
els.directShoeGridButton.addEventListener("click", directMatchShoeGrid);
els.generateShoeGridButton.addEventListener("click", generateShoeGrid);
els.clearShoeGridButton.addEventListener("click", clearShoeGrid);
els.exportShoeGridButton.addEventListener("click", exportShoeGridImage);
els.copyShoeGridButton.addEventListener("click", () => copyCanvasToClipboard(els.shoeGridCanvas));
els.openShoeGridFolderButton.addEventListener("click", openShoeGridFolder);
els.splitGridButton.addEventListener("click", splitGridRemixSources);
els.clearGridRemixButton.addEventListener("click", clearGridRemix);
els.recomposeGridButton.addEventListener("click", recomposeGridRemixSelection);
els.exportGridRemixButton.addEventListener("click", () => downloadCanvas(els.gridRemixCanvas, "grid-remix.jpg"));
els.copyGridRemixButton.addEventListener("click", () => copyCanvasToClipboard(els.gridRemixCanvas));
els.exportCanvasExpandButton.addEventListener("click", () => downloadCanvas(els.canvasExpandCanvas, "canvas-expand.jpg"));
els.copyCanvasExpandButton.addEventListener("click", () => copyCanvasToClipboard(els.canvasExpandCanvas));
if (els.checkUpdateButton) {
  els.checkUpdateButton.addEventListener("click", checkForUpdates);
}
if (els.applyUpdateButton) {
  els.applyUpdateButton.addEventListener("click", applyAvailableUpdate);
}
els.shoeGridSavePathLockButton.addEventListener("click", () => {
  const locked = !els.shoeGridSavePathLockButton.classList.contains("locked");
  els.shoeGridSavePathInput.readOnly = locked;
  els.shoeGridSavePathLockButton.classList.toggle("locked", locked);
  els.shoeGridSavePathLockButton.setAttribute("aria-pressed", String(locked));
  els.shoeGridSavePathLockButton.textContent = locked ? "已锁" : "锁";
});
els.closeImageViewerButton.addEventListener("click", closeImageViewer);
els.imageViewerOverlay.addEventListener("click", (event) => {
  if (event.target === els.imageViewerOverlay) closeImageViewer();
});
els.doodleCanvas.addEventListener("mousedown", (event) => {
  state.doodling = true;
  state.lastDoodlePoint = getCanvasPoint(event);
  paintAt(event);
});
els.doodleCanvas.addEventListener("mousemove", paintAt);
window.addEventListener("mouseup", () => {
  if (state.doodling) {
    pushDoodleHistory();
  }
  state.doodling = false;
  state.lastDoodlePoint = null;
});
window.addEventListener("resize", () => {
  if (!els.doodleOverlay.hidden) fitDoodleCanvasToShell();
  fitAllPreviewCanvases();
  if (state.canvasExpandImage) fitPreviewCanvas(els.canvasExpandSourceCanvas);
  updateCanvasExpandEditorScale();
  updateCanvasExpandFrameElement();
});
els.cancelDoodleButton.addEventListener("click", () => {
  els.doodleOverlay.hidden = true;
  state.doodleTarget = null;
  state.doodleHistory = [];
  state.doodleHistoryIndex = -1;
  updateDoodleHistoryButtons();
});
els.undoDoodleButton.addEventListener("click", undoDoodle);
els.redoDoodleButton.addEventListener("click", redoDoodle);
els.saveDoodleButton.addEventListener("click", saveDoodleBoard);

document.addEventListener("paste", (event) => {
  const file = Array.from(event.clipboardData?.files || []).find((item) => item.type.startsWith("image/"));
  if (!file) return;
  loadClipboardImageForActiveModule(file);
});

function bindImageDrop(target, loader = loadImageFromFile) {
  target.addEventListener("dragover", (event) => {
    event.preventDefault();
    target.classList.add("dragging");
  });
  target.addEventListener("dragleave", () => target.classList.remove("dragging"));
  target.addEventListener("drop", (event) => {
    event.preventDefault();
    target.classList.remove("dragging");
    const file = Array.from(event.dataTransfer.files).find((item) => item.type.startsWith("image/"));
    if (file) loader(file);
  });
}

bindImageDrop(els.dropZone);
bindImageDrop(els.finalDropZone, loadFinalImageFromFile);
updateGridPresetButtons();
updateSemanticControlState();
renderGridRemixSources();
renderGridRemixTiles();
loadUpdateStatus();
