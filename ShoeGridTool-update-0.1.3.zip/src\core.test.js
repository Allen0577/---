const test = require("node:test");
const assert = require("node:assert/strict");

const {
  findAlphaBounds,
  findMaskBounds,
  fitRectContain,
  createSquareCanvasPlan,
  createGridLayout,
  getShoeGridExportSpec,
  roundUpToMultiple,
  createCanvasExpandPlan,
} = require("./core");

test("findAlphaBounds returns the tight rectangle around visible alpha pixels", () => {
  const pixels = new Uint8ClampedArray(5 * 4 * 4);
  const setAlpha = (x, y, alpha) => {
    pixels[(y * 5 + x) * 4 + 3] = alpha;
  };
  setAlpha(1, 1, 255);
  setAlpha(3, 2, 128);

  assert.deepEqual(findAlphaBounds(pixels, 5, 4, 10), {
    x: 1,
    y: 1,
    width: 3,
    height: 2,
  });
});

test("findAlphaBounds returns null when there are no visible pixels", () => {
  const pixels = new Uint8ClampedArray(3 * 3 * 4);

  assert.equal(findAlphaBounds(pixels, 3, 3), null);
});

test("findMaskBounds ignores mask alpha and uses grayscale mask pixels", () => {
  const pixels = new Uint8ClampedArray(5 * 4 * 4);
  for (let offset = 0; offset < pixels.length; offset += 4) {
    pixels[offset + 3] = 255;
  }
  const setMask = (x, y, value) => {
    const offset = (y * 5 + x) * 4;
    pixels[offset] = value;
    pixels[offset + 1] = value;
    pixels[offset + 2] = value;
  };
  setMask(2, 1, 255);
  setMask(4, 3, 90);

  assert.deepEqual(findMaskBounds(pixels, 5, 4, 28), {
    x: 2,
    y: 1,
    width: 3,
    height: 3,
  });
});

test("fitRectContain centers a source rectangle inside a square cell", () => {
  assert.deepEqual(fitRectContain(400, 200, 1024, 0.82), {
    x: 92,
    y: 302,
    width: 840,
    height: 420,
  });
});

test("createSquareCanvasPlan pads the short side to match the long side", () => {
  assert.deepEqual(createSquareCanvasPlan(600, 300), {
    size: 600,
    x: 0,
    y: 150,
    width: 600,
    height: 300,
  });

  assert.deepEqual(createSquareCanvasPlan(280, 640), {
    size: 640,
    x: 180,
    y: 0,
    width: 280,
    height: 640,
  });
});

test("createGridLayout returns a 2x2 square layout", () => {
  assert.deepEqual(createGridLayout(4, 1024), {
    cols: 2,
    rows: 2,
    cellSize: 1024,
    width: 2048,
    height: 2048,
  });
});

test("getShoeGridExportSpec exports the 2x2 shoe grid as jpg", () => {
  assert.deepEqual(getShoeGridExportSpec(), {
    mimeType: "image/jpeg",
    quality: 0.94,
    filename: "shoe-grid.jpg",
  });
});

test("roundUpToMultiple rounds export dimensions up to the next multiple", () => {
  assert.equal(roundUpToMultiple(1025, 16), 1040);
  assert.equal(roundUpToMultiple(784, 16), 784);
});

test("createCanvasExpandPlan pads user expansion output to multiples of 16", () => {
  assert.deepEqual(createCanvasExpandPlan(1000, 700, {
    top: 12,
    right: 13,
    bottom: 40,
    left: 0,
  }), {
    contentWidth: 1013,
    contentHeight: 752,
    width: 1024,
    height: 752,
    imageX: 0,
    imageY: 12,
    extraRight: 11,
    extraBottom: 0,
  });
});
