function normalizeVersion(version) {
  return String(version || "")
    .trim()
    .replace(/^v/i, "")
    .split(".")
    .map((part) => {
      const value = Number.parseInt(part, 10);
      return Number.isFinite(value) ? value : 0;
    });
}

function compareVersions(left, right) {
  const leftParts = normalizeVersion(left);
  const rightParts = normalizeVersion(right);
  const maxLength = Math.max(leftParts.length, rightParts.length, 3);

  for (let index = 0; index < maxLength; index += 1) {
    const leftValue = leftParts[index] || 0;
    const rightValue = rightParts[index] || 0;
    if (leftValue > rightValue) return 1;
    if (leftValue < rightValue) return -1;
  }
  return 0;
}

function isNewerVersion(candidate, current) {
  return compareVersions(candidate, current) > 0;
}

function parseJsonText(text) {
  return JSON.parse(String(text || "").replace(/^\uFEFF/, ""));
}

function validateManifest(payload) {
  const manifest = payload && typeof payload === "object" ? payload : {};
  const version = String(manifest.version || "").trim().replace(/^v/i, "");
  const notes = String(manifest.notes || "").trim();
  const packageUrl = String(manifest.packageUrl || "").trim();
  const sha256 = String(manifest.sha256 || "").trim().toLowerCase();

  if (!/^\d+\.\d+\.\d+([-.][0-9a-z]+)?$/i.test(version)) {
    throw new Error("更新清单 version 格式不正确");
  }
  if (!packageUrl) {
    throw new Error("更新清单缺少 packageUrl");
  }
  if (!/^https:\/\//i.test(packageUrl)) {
    throw new Error("更新包地址必须使用 https");
  }
  if (!/^[a-f0-9]{64}$/i.test(sha256)) {
    throw new Error("更新清单 sha256 格式不正确");
  }

  return { version, notes, packageUrl, sha256 };
}

function isSafeZipEntry(entryName) {
  const normalized = String(entryName || "").replace(/\\/g, "/");
  if (!normalized || normalized.endsWith("/")) return true;
  if (normalized.startsWith("/") || /^[a-z]:\//i.test(normalized)) return false;
  if (normalized.split("/").some((part) => part === "..")) return false;
  return normalized === "package.json" || normalized.startsWith("src/");
}

module.exports = {
  compareVersions,
  isNewerVersion,
  parseJsonText,
  validateManifest,
  isSafeZipEntry,
};
