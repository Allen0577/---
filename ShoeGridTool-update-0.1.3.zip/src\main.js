﻿const { app, BrowserWindow, Menu, clipboard, nativeImage, ipcMain, shell } = require("electron");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { spawn } = require("node:child_process");
const https = require("node:https");
const { pipeline } = require("node:stream/promises");
const { validateManifest, isNewerVersion, isSafeZipEntry, parseJsonText } = require("./update-core");

const SAM3_MODEL_NAME = "sam3.1_multiplex_fp16.safetensors";
const EXTERNAL_SAM3_ROOT = "F:\\ComfyUI_Mie_V6.01";
const SAM3_RUNNER_NAME = "sam3_segment.py";
const SAM3_TIMEOUT_MS = 10 * 60 * 1000;
const SETTINGS_FILE_NAME = "shoe-transfer-settings.json";
const APP_PACKAGE_PATH = path.join(__dirname, "..", "package.json");
const UPDATE_TEMP_DIR_NAME = "shoe-grid-tool-update";

function readAppPackage() {
  try {
    return parseJsonText(fs.readFileSync(APP_PACKAGE_PATH, "utf8"));
  } catch {
    return {};
  }
}

function getCurrentVersion() {
  return String(readAppPackage().version || "0.0.0");
}

function getManifestUrl() {
  return String(
    process.env.SHOE_GRID_UPDATE_MANIFEST_URL ||
    readAppPackage().update?.manifestUrl ||
    "",
  ).trim();
}

function requestJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { "User-Agent": "ShoeGridToolUpdater" } }, (response) => {
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        response.resume();
        requestJson(new URL(response.headers.location, url).toString()).then(resolve, reject);
        return;
      }
      if (response.statusCode !== 200) {
        response.resume();
        reject(new Error(`更新服务器返回 ${response.statusCode}`));
        return;
      }

      let body = "";
      response.setEncoding("utf8");
      response.on("data", (chunk) => {
        body += chunk;
      });
      response.on("end", () => {
        try {
          resolve(parseJsonText(body));
        } catch {
          reject(new Error("更新清单不是有效 JSON"));
        }
      });
    }).on("error", reject);
  });
}

function downloadFile(url, outputPath) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, { headers: { "User-Agent": "ShoeGridToolUpdater" } }, async (response) => {
      try {
        if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
          response.resume();
          await downloadFile(new URL(response.headers.location, url).toString(), outputPath);
          resolve(outputPath);
          return;
        }
        if (response.statusCode !== 200) {
          response.resume();
          reject(new Error(`更新包下载失败：${response.statusCode}`));
          return;
        }
        fs.mkdirSync(path.dirname(outputPath), { recursive: true });
        await pipeline(response, fs.createWriteStream(outputPath));
        resolve(outputPath);
      } catch (error) {
        reject(error);
      }
    });
    request.on("error", reject);
  });
}

function hashFile(filePath) {
  const hash = crypto.createHash("sha256");
  hash.update(fs.readFileSync(filePath));
  return hash.digest("hex");
}

function runPowerShell(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", ...args], {
      windowsHide: true,
    });
    let stderr = "";
    child.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error(stderr.trim() || `PowerShell 退出码 ${code}`));
    });
  });
}

async function extractZip(zipPath, outputDir) {
  fs.rmSync(outputDir, { recursive: true, force: true });
  fs.mkdirSync(outputDir, { recursive: true });
  await runPowerShell([
    "-Command",
    "Expand-Archive -LiteralPath $args[0] -DestinationPath $args[1] -Force",
    zipPath,
    outputDir,
  ]);
}

function getRelativeFiles(rootDir) {
  const result = [];
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(fullPath);
      } else {
        result.push(path.relative(rootDir, fullPath).replace(/\\/g, "/"));
      }
    }
  };
  walk(rootDir);
  return result;
}

function copyUpdateFiles(extractedDir, appRoot) {
  const files = getRelativeFiles(extractedDir);
  for (const relativeFile of files) {
    if (!isSafeZipEntry(relativeFile)) {
      throw new Error(`更新包包含不允许的文件：${relativeFile}`);
    }
  }

  for (const relativeFile of files) {
    const source = path.join(extractedDir, relativeFile);
    const target = path.join(appRoot, relativeFile);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
  }
  return files;
}

function getUniqueOutputPath(outputPath) {
  if (!fs.existsSync(outputPath)) return outputPath;

  const dir = path.dirname(outputPath);
  const ext = path.extname(outputPath) || ".png";
  const baseName = path.basename(outputPath, ext);
  let counter = 2;
  let nextPath = path.join(dir, `${baseName}-${counter}${ext}`);
  while (fs.existsSync(nextPath)) {
    counter += 1;
    nextPath = path.join(dir, `${baseName}-${counter}${ext}`);
  }
  return nextPath;
}
function getSettingsPath() {
  return path.join(app.getPath("userData"), SETTINGS_FILE_NAME);
}

function readSettings() {
  try {
    const settingsPath = getSettingsPath();
    if (!fs.existsSync(settingsPath)) return {};
    return JSON.parse(fs.readFileSync(settingsPath, "utf8"));
  } catch {
    return {};
  }
}

function writeSettings(nextSettings) {
  const settingsPath = getSettingsPath();
  fs.mkdirSync(path.dirname(settingsPath), { recursive: true });
  fs.writeFileSync(settingsPath, JSON.stringify(nextSettings, null, 2), "utf8");
  return nextSettings;
}

function createWindow() {
  Menu.setApplicationMenu(null);

  const win = new BrowserWindow({
    width: 2048,
    height: 1152,
    minWidth: 1440,
    minHeight: 900,
    backgroundColor: "#eef4fb",
    show: false,
    icon: path.join(__dirname, "assets", "app-icon.ico"),
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, "preload.js"),
    },
  });

  win.once("ready-to-show", () => {
    win.show();
  });
  win.webContents.once("did-fail-load", () => {
    if (!win.isVisible()) win.show();
  });
  win.loadFile(path.join(__dirname, "index.html"));
}

app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

ipcMain.handle("save-png", async (_event, payload) => {
  const target = String(payload.target || "").trim();
  if (!target) {
    throw new Error("保存路径不能为空");
  }

  const stats = fs.existsSync(target) ? fs.statSync(target) : null;
  const requestedOutputPath = stats?.isDirectory()
    ? path.join(target, payload.filename || "shoe-transfer-final-4k.jpg")
    : target;
  const outputPath = getUniqueOutputPath(requestedOutputPath);
  const base64 = String(payload.dataUrl || "").replace(/^data:image\/(png|jpeg|jpg);base64,/, "");
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, Buffer.from(base64, "base64"));
  return outputPath;
});

ipcMain.handle("save-png-list", async (_event, payload) => {
  const target = String(payload.target || "").trim();
  if (!target) {
    throw new Error("保存文件夹不能为空");
  }

  const outputDir = fs.existsSync(target) && fs.statSync(target).isDirectory()
    ? target
    : path.dirname(target);
  fs.mkdirSync(outputDir, { recursive: true });

  return payload.items.map((item, index) => {
    const filename = item.filename || `slice-${index + 1}.jpg`;
    const outputPath = getUniqueOutputPath(path.join(outputDir, filename));
    const base64 = String(item.dataUrl || "").replace(/^data:image\/(png|jpeg|jpg);base64,/, "");
    fs.writeFileSync(outputPath, Buffer.from(base64, "base64"));
    return outputPath;
  });
});

ipcMain.handle("copy-png", async (_event, dataUrl) => {
  clipboard.writeImage(nativeImage.createFromDataURL(String(dataUrl || "")));
  return true;
});

ipcMain.handle("open-path", async (_event, targetPath) => {
  const target = String(targetPath || "").trim();
  if (!target) {
    throw new Error("保存路径不能为空");
  }

  const openTarget = fs.existsSync(target) && fs.statSync(target).isDirectory()
    ? target
    : path.dirname(target);
  fs.mkdirSync(openTarget, { recursive: true });
  const error = await shell.openPath(openTarget);
  if (error) throw new Error(error);
  return openTarget;
});

ipcMain.handle("get-save-path-lock", async () => {
  const settings = readSettings();
  return {
    savePath: String(settings.savePath || ""),
    locked: Boolean(settings.savePathLocked),
  };
});

ipcMain.handle("set-save-path-lock", async (_event, payload) => {
  const settings = readSettings();
  const savePath = String(payload?.savePath || "").trim();
  const locked = Boolean(payload?.locked);

  if (locked && !savePath) {
    throw new Error("保存路径不能为空");
  }

  settings.savePath = locked ? savePath : "";
  settings.savePathLocked = locked;
  return writeSettings(settings);
});

ipcMain.handle("update:get-status", async () => ({
  currentVersion: getCurrentVersion(),
  manifestUrl: getManifestUrl(),
}));

ipcMain.handle("update:check", async () => {
  const manifestUrl = getManifestUrl();
  if (!manifestUrl || manifestUrl.includes("OWNER/REPO")) {
    throw new Error("还没有配置 GitHub 更新地址，请先把 package.json 里的 OWNER/REPO 改成真实仓库");
  }

  const manifest = validateManifest(await requestJson(manifestUrl));
  const currentVersion = getCurrentVersion();
  return {
    ...manifest,
    currentVersion,
    hasUpdate: isNewerVersion(manifest.version, currentVersion),
  };
});

ipcMain.handle("update:download-and-apply", async (_event, manifestPayload) => {
  const manifest = validateManifest(manifestPayload);
  if (!isNewerVersion(manifest.version, getCurrentVersion())) {
    return { updated: false, message: "当前已经是最新版本" };
  }

  const tempRoot = path.join(app.getPath("temp"), UPDATE_TEMP_DIR_NAME);
  const zipPath = path.join(tempRoot, `update-${manifest.version}.zip`);
  const extractDir = path.join(tempRoot, `extracted-${Date.now()}`);
  fs.rmSync(tempRoot, { recursive: true, force: true });
  fs.mkdirSync(tempRoot, { recursive: true });

  await downloadFile(manifest.packageUrl, zipPath);
  const actualHash = hashFile(zipPath);
  if (actualHash.toLowerCase() !== manifest.sha256.toLowerCase()) {
    throw new Error("更新包校验失败，请重新发布或重新下载");
  }

  await extractZip(zipPath, extractDir);
  const copiedFiles = copyUpdateFiles(extractDir, path.join(__dirname, ".."));

  setTimeout(() => {
    app.relaunch();
    app.exit(0);
  }, 600);

  return {
    updated: true,
    version: manifest.version,
    copiedFiles,
  };
});

function dataUrlToBuffer(dataUrl) {
  const base64 = String(dataUrl || "").replace(/^data:image\/(png|jpeg|jpg);base64,/, "");
  return Buffer.from(base64, "base64");
}

function firstExistingPath(candidates) {
  return candidates.find((candidate) => candidate && fs.existsSync(candidate)) || "";
}

function getPackagedResourcePath(...parts) {
  return path.join(process.resourcesPath || "", ...parts);
}

function getPythonPath() {
  return firstExistingPath([
    getPackagedResourcePath("sam3-runtime", "python_embeded", "python.exe"),
    path.join(EXTERNAL_SAM3_ROOT, "python_embeded", "python.exe"),
  ]);
}

function getSam3ModelPath() {
  return firstExistingPath([
    getPackagedResourcePath("sam3", "models", "sam3", SAM3_MODEL_NAME),
    path.join(EXTERNAL_SAM3_ROOT, "ComfyUI", "models", "sam3", SAM3_MODEL_NAME),
  ]);
}

function getEasySam3PluginPath() {
  return firstExistingPath([
    getPackagedResourcePath("sam3", "custom_nodes", "ComfyUI-Easy-Sam3"),
    path.join(EXTERNAL_SAM3_ROOT, "ComfyUI", "custom_nodes", "ComfyUI-Easy-Sam3"),
  ]);
}

function getSam3RunnerPath() {
  return firstExistingPath([
    getPackagedResourcePath("sam3", SAM3_RUNNER_NAME),
    path.join(__dirname, SAM3_RUNNER_NAME),
  ]);
}

function getMissingSam3Reason(paths) {
  if (!paths.pythonPath) return "SAM3 内置 Python 运行环境缺失";
  if (!paths.modelPath) return "SAM3 模型文件缺失";
  if (!paths.pluginPath) return "SAM3 本地插件文件缺失";
  if (!paths.runnerPath) return "SAM3 本地执行脚本缺失";
  return "";
}

function parseSam3RunnerOutput(stdout) {
  const match = String(stdout || "").match(/__SAM3_RESULT__(\{[\s\S]*\})__END__/);
  if (!match) {
    throw new Error("SAM3 没有返回可读取的结果");
  }
  return JSON.parse(match[1]);
}

function runSam3Runner(pythonPath, runnerPath, jobPath) {
  return new Promise((resolve) => {
    const child = spawn(pythonPath, ["-s", runnerPath, jobPath], {
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
      env: {
        ...process.env,
        PYTHONIOENCODING: "utf-8",
        PYTHONUTF8: "1",
      },
    });

    let stdout = "";
    let stderr = "";
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      child.kill();
      resolve({ ok: false, reason: "SAM3 识别超时", stdout, stderr });
    }, SAM3_TIMEOUT_MS);

    child.stdout.on("data", (chunk) => {
      stdout += chunk.toString("utf8");
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk.toString("utf8");
    });
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ ok: false, reason: error.message, stdout, stderr });
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (code !== 0) {
        const parsed = safeParseSam3Output(stdout);
        resolve({
          ok: false,
          reason: parsed?.reason || stderr.trim() || `SAM3 识别失败，退出码 ${code}`,
          stdout,
          stderr,
        });
        return;
      }

      try {
        resolve({ ok: true, result: parseSam3RunnerOutput(stdout), stdout, stderr });
      } catch (error) {
        resolve({ ok: false, reason: error.message, stdout, stderr });
      }
    });
  });
}

function safeParseSam3Output(stdout) {
  try {
    return parseSam3RunnerOutput(stdout);
  } catch (_error) {
    return null;
  }
}

function makeEmptySam3Response(items, reason) {
  return {
    ok: false,
    reason,
    items: items.map((item) => ({ ...item, maskDataUrl: "" })),
  };
}

function createSam3Job(payload, paths) {
  const items = Array.isArray(payload?.items) ? payload.items : [];
  const publicRoot = process.env.PUBLIC || "C:\\Users\\Public";
  const jobDir = path.join(publicRoot, "shoe-transfer-sam3-jobs", `job-${crypto.randomUUID()}`);
  fs.mkdirSync(jobDir, { recursive: true });

  const jobItems = items.map((item, order) => {
    const inputPath = path.join(jobDir, `crop-${order + 1}.png`);
    const maskPath = path.join(jobDir, `mask-${order + 1}.png`);
    fs.writeFileSync(inputPath, dataUrlToBuffer(item.dataUrl));
    return {
      index: item.index,
      row: item.row,
      col: item.col,
      inputPath,
      maskPath,
    };
  });

  const job = {
    prompt: String(payload?.prompt || "").trim(),
    threshold: 0.4,
    resolution: 1008,
    device: "auto",
    modelPath: paths.modelPath,
    pluginPath: paths.pluginPath,
    items: jobItems,
  };
  const jobPath = path.join(jobDir, "job.json");
  fs.writeFileSync(jobPath, JSON.stringify(job, null, 2), "utf8");
  return { jobDir, jobPath, jobItems };
}

ipcMain.handle("segment-semantic-crops", async (_event, payload) => {
  const items = Array.isArray(payload?.items) ? payload.items : [];
  const prompt = String(payload?.prompt || "").trim();

  if (!items.length) {
    return makeEmptySam3Response(items, "没有可识别的裁剪图");
  }
  if (!prompt) {
    return makeEmptySam3Response(items, "请输入语义关键词");
  }

  const paths = {
    pythonPath: getPythonPath(),
    modelPath: getSam3ModelPath(),
    pluginPath: getEasySam3PluginPath(),
    runnerPath: getSam3RunnerPath(),
  };
  const missingReason = getMissingSam3Reason(paths);
  if (missingReason) {
    return makeEmptySam3Response(items, missingReason);
  }

  const job = createSam3Job(payload, paths);
  try {
    const run = await runSam3Runner(paths.pythonPath, paths.runnerPath, job.jobPath);
    if (!run.ok || !run.result?.ok) {
      return makeEmptySam3Response(items, run.reason || run.result?.reason || "SAM3 识别失败");
    }

    const outputByIndex = new Map((run.result.items || []).map((item) => [String(item.index), item]));
    const results = items.map((item, order) => {
      const jobItem = job.jobItems[order];
      const output = outputByIndex.get(String(item.index));
      const maskPath = output?.maskPath || jobItem.maskPath;
      const maskDataUrl = fs.existsSync(maskPath)
        ? `data:image/png;base64,${fs.readFileSync(maskPath).toString("base64")}`
        : "";
      return { ...item, maskDataUrl };
    });

    return {
      ok: true,
      engine: "local-sam3",
      device: run.result.device || "auto",
      items: results,
    };
  } finally {
    fs.rmSync(job.jobDir, { recursive: true, force: true });
  }
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});




