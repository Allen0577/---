function assertPositiveInteger(value, name) {
  if (!Number.isInteger(value) || value <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
}

function computeSlices(image, cols, rows) {
  assertPositiveInteger(cols, "cols");
  assertPositiveInteger(rows, "rows");

  const cellWidth = image.width / cols;
  const cellHeight = image.height / rows;
  const slices = [];

  for (let row = 0; row < rows; row += 1) {
    for (let col = 0; col < cols; col += 1) {
      const x = Math.round(col * cellWidth);
      const y = Math.round(row * cellHeight);
      const nextX = Math.round((col + 1) * cellWidth);
      const nextY = Math.round((row + 1) * cellHeight);

      slices.push({
        index: row * cols + col,
        col,
        row,
        x,
        y,
        width: nextX - x,
        height: nextY - y,
      });
    }
  }

  return slices;
}

function expandRect(rect, padding, bounds) {
  const x = Math.max(0, Math.floor(rect.x - padding));
  const y = Math.max(0, Math.floor(rect.y - padding));
  const right = Math.min(bounds.width, Math.ceil(rect.x + rect.width + padding));
  const bottom = Math.min(bounds.height, Math.ceil(rect.y + rect.height + padding));

  return {
    x,
    y,
    width: Math.max(1, right - x),
    height: Math.max(1, bottom - y),
  };
}

function mapEditedCropToSource({ editedGrid, cols, rows, crop, cellIndex }) {
  assertPositiveInteger(cols, "cols");
  assertPositiveInteger(rows, "rows");

  const col = cellIndex % cols;
  const row = Math.floor(cellIndex / cols);
  const cellWidth = Math.round(editedGrid.width / cols);
  const cellHeight = Math.round(editedGrid.height / rows);

  return {
    source: {
      x: crop.x,
      y: crop.y,
      width: crop.width,
      height: crop.height,
    },
    editedCell: {
      x: col * cellWidth,
      y: row * cellHeight,
      width: cellWidth,
      height: cellHeight,
    },
  };
}

function findAlphaBounds(pixels, width, height, alphaThreshold = 1) {
  assertPositiveInteger(width, "width");
  assertPositiveInteger(height, "height");

  if (!pixels || pixels.length < width * height * 4) {
    throw new Error("pixels must contain RGBA data for the full image");
  }

  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;
  const threshold = Math.max(0, Number(alphaThreshold) || 0);

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const alpha = pixels[(y * width + x) * 4 + 3];
      if (alpha <= threshold) continue;
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
    }
  }

  if (maxX < minX || maxY < minY) return null;
  return {
    x: minX,
    y: minY,
    width: maxX - minX + 1,
    height: maxY - minY + 1,
  };
}

function findMaskBounds(pixels, width, height, maskThreshold = 28) {
  assertPositiveInteger(width, "width");
  assertPositiveInteger(height, "height");

  if (!pixels || pixels.length < width * height * 4) {
    throw new Error("pixels must contain RGBA data for the full mask");
  }

  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;
  const threshold = Math.max(0, Number(maskThreshold) || 0);

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const offset = (y * width + x) * 4;
      const maskValue = Math.max(pixels[offset], pixels[offset + 1], pixels[offset + 2]);
      if (maskValue <= threshold) continue;
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
    }
  }

  if (maxX < minX || maxY < minY) return null;
  return {
    x: minX,
    y: minY,
    width: maxX - minX + 1,
    height: maxY - minY + 1,
  };
}

function fitRectContain(sourceWidth, sourceHeight, cellSize, fillRatio = 0.82) {
  assertPositiveInteger(sourceWidth, "sourceWidth");
  assertPositiveInteger(sourceHeight, "sourceHeight");
  assertPositiveInteger(cellSize, "cellSize");

  const ratio = Math.min(1, Math.max(0.1, Number(fillRatio) || 0.82));
  const targetSize = cellSize * ratio;
  const scale = Math.min(targetSize / sourceWidth, targetSize / sourceHeight);
  const width = Math.round(sourceWidth * scale);
  const height = Math.round(sourceHeight * scale);

  return {
    x: Math.round((cellSize - width) / 2),
    y: Math.round((cellSize - height) / 2),
    width,
    height,
  };
}

function createSquareCanvasPlan(sourceWidth, sourceHeight) {
  assertPositiveInteger(sourceWidth, "sourceWidth");
  assertPositiveInteger(sourceHeight, "sourceHeight");

  const size = Math.max(sourceWidth, sourceHeight);
  return {
    size,
    x: Math.round((size - sourceWidth) / 2),
    y: Math.round((size - sourceHeight) / 2),
    width: sourceWidth,
    height: sourceHeight,
  };
}

function createGridLayout(itemCount = 4, cellSize = 1024) {
  assertPositiveInteger(itemCount, "itemCount");
  assertPositiveInteger(cellSize, "cellSize");

  const cols = itemCount <= 1 ? 1 : 2;
  const rows = Math.ceil(itemCount / cols);
  return {
    cols,
    rows,
    cellSize,
    width: cols * cellSize,
    height: rows * cellSize,
  };
}

function roundUpToMultiple(value, multiple = 16) {
  assertPositiveInteger(value, "value");
  assertPositiveInteger(multiple, "multiple");
  return Math.ceil(value / multiple) * multiple;
}

function createCanvasExpandPlan(sourceWidth, sourceHeight, padding = {}) {
  assertPositiveInteger(sourceWidth, "sourceWidth");
  assertPositiveInteger(sourceHeight, "sourceHeight");

  const top = Math.max(0, Math.round(Number(padding.top) || 0));
  const right = Math.max(0, Math.round(Number(padding.right) || 0));
  const bottom = Math.max(0, Math.round(Number(padding.bottom) || 0));
  const left = Math.max(0, Math.round(Number(padding.left) || 0));
  const contentWidth = sourceWidth + left + right;
  const contentHeight = sourceHeight + top + bottom;
  const width = roundUpToMultiple(contentWidth, 16);
  const height = roundUpToMultiple(contentHeight, 16);

  return {
    contentWidth,
    contentHeight,
    width,
    height,
    imageX: left,
    imageY: top,
    extraRight: width - contentWidth,
    extraBottom: height - contentHeight,
  };
}

function getShoeGridExportSpec() {
  return {
    mimeType: "image/jpeg",
    quality: 0.94,
    filename: "shoe-grid.jpg",
  };
}

module.exports = {
  computeSlices,
  expandRect,
  mapEditedCropToSource,
  findAlphaBounds,
  findMaskBounds,
  fitRectContain,
  createSquareCanvasPlan,
  createGridLayout,
  getShoeGridExportSpec,
  roundUpToMultiple,
  createCanvasExpandPlan,
};
